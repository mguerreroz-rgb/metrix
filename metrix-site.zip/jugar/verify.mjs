import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";

await import("./script.js");

const { MISSIONS, QUESTIONS, LETTERS, buildCorrectLetterSchedule, naturalizeSpeechText } = globalThis.METRIX_TEST_API;
const [html, css, javascript] = await Promise.all([
  readFile(new URL("./index.html", import.meta.url), "utf8"),
  readFile(new URL("./styles.css", import.meta.url), "utf8"),
  readFile(new URL("./script.js", import.meta.url), "utf8"),
]);

const htmlIds = [...html.matchAll(/\sid=["']([^"']+)["']/g)].map((match) => match[1]);
assert.equal(new Set(htmlIds).size, htmlIds.length, "No deben existir identificadores HTML repetidos");
const referencedIds = [...javascript.matchAll(/\$\("#([^"']+)"\)/g)].map((match) => match[1]);
referencedIds.forEach((id) => assert.ok(htmlIds.includes(id), `El control #${id} debe existir en el HTML`));

assert.equal(MISSIONS.length, 4, "Deben existir cuatro misiones");
assert.equal(QUESTIONS.length, 20, "Deben existir veinte desafíos");
assert.equal(new Set(QUESTIONS.map((question) => question.id)).size, 20, "Los identificadores deben ser únicos");
assert.equal(new Set(QUESTIONS.map((question) => question.title)).size, 20, "Los títulos deben ser únicos");
assert.equal(new Set(QUESTIONS.map((question) => question.prompt)).size, 20, "Los enunciados deben ser únicos");

MISSIONS.forEach((mission) => {
  assert.equal(QUESTIONS.filter((question) => question.mission === mission.id).length, 5, `La misión ${mission.id} debe tener cinco preguntas`);
});

QUESTIONS.forEach((question) => {
  assert.equal(question.options.length, 5, `${question.id} debe tener cinco opciones`);
  assert.equal(question.options.filter((option) => option.correct).length, 1, `${question.id} debe tener una sola respuesta correcta`);
  assert.equal(new Set(question.options.map((option) => option.text)).size, 5, `${question.id} no debe repetir alternativas`);
  assert.ok(question.socratic.length > 30, `${question.id} necesita una pregunta socrática sustantiva`);
  assert.ok(question.explanation.length > 30, `${question.id} necesita retroalimentación explicativa`);
});

const schedules = new Set();
for (let seed = 1; seed <= 2000; seed += 1) {
  const schedule = buildCorrectLetterSchedule(seed);
  schedules.add(schedule.join(""));
  assert.equal(schedule.length, 20);
  LETTERS.forEach((letter) => assert.equal(schedule.filter((value) => value === letter).length, 4));
  assert.ok(schedule.every((letter, index) => index === 0 || letter !== schedule[index - 1]), "No debe repetirse inmediatamente la letra correcta");
}
assert.ok(schedules.size > 1900, "La distribución debe variar entre sesiones");

[
  "screen-landing",
  "screen-setup",
  "screen-briefing",
  "screen-map",
  "screen-mission-intro",
  "screen-question",
  "screen-mission-complete",
  "screen-final",
  "accessibility-toggle",
  "settings-accessibility",
  "music-toggle",
  "music-volume",
  "narration-toggle",
  "narration-volume",
  "narration-rate",
  "contrast-toggle",
  "text-toggle",
  "foundation-dialog",
  "download-instructions",
  "print-diplomas",
  "print-report",
].forEach((id) => assert.match(html, new RegExp(`id=["']${id}["']`)));

assert.match(css, /@media \(max-width: 680px\)/);
assert.match(css, /prefers-reduced-motion/);
assert.match(javascript, /state\.attempt === 1 \? 2 : 1/);
assert.match(javascript, /state\.missionScores\[state\.currentMission\] >= 6/);
assert.match(javascript, /CC BY-NC-SA 4\.0/);
assert.match(javascript, /assets\/audio\/misterio\.wav/);
assert.match(javascript, /assets\/audio\/motivacion\.wav/);
assert.match(javascript, /speechChunks/);
assert.match(html, /assets\/vendor\/jspdf\.umd\.min\.js/);
assert.match(javascript, /createDiplomaPdf/);
assert.match(javascript, /createReportPdf/);
assert.match(javascript, /createInstructionsPdf/);
assert.match(javascript, /documentPdf\.save\(filename\)/);
assert.match(javascript, /grados Celsius/);
assert.doesNotMatch(javascript, /cent[ií]grados/i, "La lectura debe utilizar la denominación Celsius");
assert.equal(naturalizeSpeechText("20 °C"), "20 grados Celsius", "La narración debe leer °C como grados Celsius");
assert.doesNotMatch(javascript, /window\.open\(/, "Los PDF no deben depender de ventanas emergentes");
assert.doesNotMatch(javascript, /ventanas emergentes/i, "No debe mostrarse un aviso de ventanas emergentes");
assert.match(html, /assets\/images\/licencia-cc-by-nc-sa-4-0\.png/);
assert.match(html, /misión individual basada en evidencias/i);
assert.match(html, /Estos controles permanecen disponibles en todas las escenas y no bloquean los botones para continuar/i);
assert.doesNotMatch(javascript, /continue.*narration|narration.*continue|disabled.*narration/i, "La narración no debe bloquear los controles de avance");
assert.doesNotMatch(html, /equipo|grupal|colectiv/i, "La experiencia debe presentarse como individual");
assert.doesNotMatch(html, /https?:\/\//, "La página debe funcionar sin recursos externos");

const requiredAssets = [
  "assets/vendor/jspdf.umd.min.js",
  "assets/audio/misterio.wav",
  "assets/audio/motivacion.wav",
  "assets/images/portada-metrix.webp",
  "assets/images/registro-analista-individual.webp",
  "assets/images/final-metrix.webp",
  "assets/images/licencia-cc-by-nc-sa-4-0.png",
  ...MISSIONS.map((mission) => mission.image),
  ...MISSIONS.map((mission) => mission.badgeImage),
  ...Array.from({ length: 12 }, (_, index) => `assets/images/avatares/avatar-${String(index + 1).padStart(2, "0")}-${["balanza", "regla", "cronometro", "termometro", "brujula", "microscopio", "probeta", "escuadra", "sensor", "candela", "electroiman", "telescopio"][index]}.webp`),
];

await Promise.all(requiredAssets.map((asset) => access(new URL(asset, import.meta.url))));

console.log(`METRIX verificado: 4 misiones, 20 preguntas únicas, aleatorización equilibrada y ${requiredAssets.length} recursos multimedia locales.`);
