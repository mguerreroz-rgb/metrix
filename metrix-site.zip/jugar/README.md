# METRIX · Tutor socrático gamificado

Actividad web local sobre mediciones y sistemas de unidades para estudiantes que ingresan a universidades del Ecuador.

## Cómo abrirla

1. Descomprime la carpeta si recibiste el archivo ZIP.
2. Abre `index.html` con Google Chrome, Microsoft Edge, Firefox o Safari.
3. No se necesita conexión a internet ni instalación.

## Estructura

- `index.html`: escenas y controles de la experiencia.
- `styles.css`: diseño visual, adaptabilidad y accesibilidad.
- `script.js`: preguntas, tutor socrático, puntuación, sonido, narración, progreso y reportes.
- `assets/images/`: portada, registro, cuatro misiones, doce avatares, cuatro insignias, licencia y escena final.
- `assets/audio/`: música local de misterio y motivación.
- `favicon.svg`: icono local de la página.
- `verify.mjs`: comprobaciones automáticas del banco de preguntas y la estructura.

## Funcionamiento

- Un participante con selección individual de avatar.
- Cuatro misiones y veinte desafíos.
- Primer intento correcto: 2 puntos.
- Segundo intento correcto: 1 punto.
- Segundo intento incorrecto: 0 puntos y avance automático.
- Insignia por misión al obtener al menos 6 de 10 puntos.
- Puntaje total máximo: 40 puntos.
- Una pestaña superior de **Accesibilidad**, disponible durante toda la actividad, reúne música, narración, velocidad de lectura, contraste y tamaño del texto.
- Un botón superior descarga una guía didáctica en PDF con las instrucciones completas paso a paso.
- Música y narración incluyen botones de activación y barras independientes de volumen. El contraste alto y el texto ampliado tienen botones de activación propios.
- Los controles de accesibilidad no bloquean los botones para continuar ni el avance entre escenas.
- Música de misterio desde el registro hasta las misiones y música de motivación en el cierre.
- Narración en español con selección automática de la mejor voz disponible en el dispositivo.
- La lectura hablada utiliza la denominación **grados Celsius** para el símbolo °C.
- Reporte y diploma generados y descargados directamente como PDF, sin depender de ventanas emergentes.
- El progreso y las preferencias se guardan únicamente en el navegador del dispositivo.

## Autoría y licencia

Marcos Guerrero · Leonor Sánchez · Bryan Valarezo  
Universidad Estatal de Milagro  
Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional (CC BY-NC-SA 4.0).
