"use strict";

const STORAGE_KEY = "metrix-session-v1";
const SETTINGS_KEY = "metrix-settings-v1";
const LETTERS = ["A", "B", "C", "D", "E"];

const AVATARS = [
  { name: "Balanza", image: "assets/images/avatares/avatar-01-balanza.webp" },
  { name: "Regla", image: "assets/images/avatares/avatar-02-regla.webp" },
  { name: "Cronómetro", image: "assets/images/avatares/avatar-03-cronometro.webp" },
  { name: "Termómetro", image: "assets/images/avatares/avatar-04-termometro.webp" },
  { name: "Brújula", image: "assets/images/avatares/avatar-05-brujula.webp" },
  { name: "Microscopio", image: "assets/images/avatares/avatar-06-microscopio.webp" },
  { name: "Probeta", image: "assets/images/avatares/avatar-07-probeta.webp" },
  { name: "Escuadra", image: "assets/images/avatares/avatar-08-escuadra.webp" },
  { name: "Sensor orbital", image: "assets/images/avatares/avatar-09-sensor.webp" },
  { name: "Candela", image: "assets/images/avatares/avatar-10-candela.webp" },
  { name: "Electroimán", image: "assets/images/avatares/avatar-11-electroiman.webp" },
  { name: "Telescopio", image: "assets/images/avatares/avatar-12-telescopio.webp" },
];

const MISSIONS = [
  {
    id: 1,
    code: "MISIÓN 01 · PATRONES",
    title: "Cámara de Patrones",
    short: "Cantidad, medición y Sistema Internacional",
    symbol: "SI",
    image: "assets/images/misiones/mision-1-camara-patrones.webp",
    imageAlt: "Cámara de Patrones del Sistema Internacional, con un reactor de calibración dorado.",
    color: "#53e5d2",
    badge: "Custodio del SI",
    badgeImage: "assets/images/insignias/insignia-1-custodio-si.webp",
    narrative:
      "Las referencias fundamentales han perdido sus nombres y símbolos. Deberás distinguir cantidades, unidades base, unidades derivadas y reglas de escritura para recuperar el patrón común.",
    objective:
      "Interpretar una medición como valor numérico y unidad, reconocer las siete unidades base del SI y relacionarlas con unidades derivadas frecuentes.",
    learning:
      "Una cantidad física se comunica mediante un valor numérico y una unidad. Las unidades derivadas se construyen algebraicamente a partir de las siete unidades base del SI.",
  },
  {
    id: 2,
    code: "MISIÓN 02 · ESCALAS",
    title: "Corredor de Escalas",
    short: "Notación científica, prefijos y órdenes de magnitud",
    symbol: "10ⁿ",
    image: "assets/images/misiones/mision-2-corredor-escalas.webp",
    imageAlt: "Corredor cósmico que representa el cambio entre escalas macroscópicas y microscópicas.",
    color: "#f4bd63",
    badge: "Navegante de Magnitudes",
    badgeImage: "assets/images/insignias/insignia-2-navegante-magnitudes.webp",
    narrative:
      "Las escalas del archivo se expanden y contraen sin control. Para estabilizarlas, deberás traducir entre notación decimal, potencias de diez y prefijos sin modificar la cantidad representada.",
    objective:
      "Expresar cantidades mediante notación científica y decimal, interpretar prefijos del SI y reconocer representaciones equivalentes.",
    learning:
      "La notación decimal, la notación científica y los prefijos son representaciones equivalentes. Cambiar la escritura no cambia la cantidad física.",
  },
  {
    id: 3,
    code: "MISIÓN 03 · PRECISIÓN",
    title: "Sala de Precisión",
    short: "Cifras significativas, operaciones y redondeo",
    symbol: "±",
    image: "assets/images/misiones/mision-3-sala-precision.webp",
    imageAlt: "Sala de Precisión con instrumentos de medición iluminados en azul y dorado.",
    color: "#8be28b",
    badge: "Guardián de la Precisión",
    badgeImage: "assets/images/insignias/insignia-3-guardian-precision.webp",
    narrative:
      "Los instrumentos reportan más dígitos de los que realmente pueden distinguir. Deberás decidir qué cifras son defendibles y evitar que una apariencia de exactitud sustituya a la información experimental.",
    objective:
      "Aplicar criterios de cifras significativas, precisión decimal y redondeo de acuerdo con los datos y el tipo de operación.",
    learning:
      "La precisión reportada debe ser coherente con los datos y el instrumento. Sumas y restas se limitan por posición decimal; productos y cocientes, por cifras significativas.",
  },
  {
    id: 4,
    code: "MISIÓN 04 · COHERENCIA",
    title: "Núcleo Dimensional",
    short: "Análisis dimensional y factores de conversión",
    symbol: "[ ]",
    image: "assets/images/misiones/mision-4-nucleo-dimensional.webp",
    imageAlt: "Núcleo Dimensional en un observatorio científico futurista.",
    color: "#b89cff",
    badge: "Arquitecto Dimensional",
    badgeImage: "assets/images/insignias/insignia-4-arquitecto-dimensional.webp",
    narrative:
      "El núcleo conserva ecuaciones y conversiones aparentemente correctas. Solo la cancelación de unidades y la homogeneidad dimensional permitirán separar una transformación válida de una coincidencia numérica.",
    objective:
      "Convertir unidades mediante factores equivalentes a uno y verificar la homogeneidad dimensional de expresiones físicas introductorias.",
    learning:
      "Las unidades se cancelan algebraicamente en una conversión válida. La homogeneidad dimensional es necesaria para una ecuación física, pero no basta para demostrar que sea correcta.",
  },
];

const QUESTIONS = [
  {
    id: "M1-Q1",
    mission: 1,
    title: "El informe incompleto",
    level: "Inicial",
    task: "Lectura de una medición",
    objective: "Reconocer los componentes de una medición",
    prompt: "Un informe registra «longitud de la mesa = 1.42». ¿Qué falta para comunicar una medición física completa?",
    evidence: { reading: "longitud = 1.42 ?", note: "Registro recibido por el sistema de calibración." },
    options: [
      { id: "a", text: "La unidad utilizada, por ejemplo m.", correct: true },
      { id: "b", text: "Otro decimal para que el valor parezca más preciso.", misconception: "Más decimales siempre significan mayor precisión." },
      { id: "c", text: "El nombre de la persona que realizó el cálculo.", misconception: "Confunde metadatos del informe con los componentes de una cantidad." },
      { id: "d", text: "Una segunda cantidad para poder comparar.", misconception: "Supone que una medición solo existe cuando se compara con otro resultado." },
      { id: "e", text: "Nada; todo número es por sí mismo una cantidad física.", misconception: "Trata un número aislado como resultado físico completo." },
    ],
    socraticCategory: "Aclaración conceptual",
    socratic: "Si otro laboratorio recibe únicamente el número 1.42, ¿cómo podría saber qué cantidad se midió y con qué referencia debe interpretarla?",
    explanation: "Una medición física debe comunicar el valor numérico y la unidad. El número aislado no permite interpretar ni comparar la cantidad.",
  },
  {
    id: "M1-Q2",
    mission: 1,
    title: "Las siete referencias",
    level: "Inicial",
    task: "Clasificación del SI",
    objective: "Identificar las siete unidades base",
    prompt: "¿Cuál conjunto está formado únicamente por las siete unidades base del Sistema Internacional?",
    evidence: { reading: "SI · 7 UNIDADES BASE", note: "Seleccione el conjunto sin unidades derivadas." },
    options: [
      { id: "a", text: "metro, kilogramo, segundo, amperio, kelvin, mol y candela", correct: true },
      { id: "b", text: "metro, newton, segundo, amperio, kelvin, mol y candela", misconception: "Clasifica el newton como unidad base." },
      { id: "c", text: "metro, kilogramo, hora, amperio, grado Celsius, mol y candela", misconception: "Sustituye unidades base por unidades aceptadas o de uso cotidiano." },
      { id: "d", text: "metro, kilogramo, segundo, voltio, kelvin, mol y lumen", misconception: "Incluye unidades derivadas eléctricas y luminosas." },
      { id: "e", text: "centímetro, gramo, segundo, amperio, kelvin, mol y candela", misconception: "Confunde unidades con prefijos con las unidades base definidas." },
    ],
    socraticCategory: "Clasificación",
    socratic: "¿Qué criterio permite distinguir una unidad base de otra que se obtiene combinando algebraicamente varias unidades? Aunque kilogramo incluye el prefijo kilo, ¿cuál unidad define el SI como base para la masa?",
    explanation: "Las siete unidades base son metro, kilogramo, segundo, amperio, kelvin, mol y candela. Aunque su nombre incluye el prefijo kilo, el kilogramo es la unidad base de masa; newton, voltio y lumen son unidades derivadas.",
  },
  {
    id: "M1-Q3",
    mission: 1,
    title: "Radián y estereorradián",
    level: "Medio",
    task: "Clasificación vigente",
    objective: "Diferenciar una categoría histórica de la clasificación actual",
    prompt: "¿Cómo se clasifican actualmente el radián (rad) y el estereorradián (sr) dentro del SI?",
    evidence: { reading: "rad · sr", note: "Ángulo plano y ángulo sólido." },
    options: [
      { id: "a", text: "Como unidades derivadas coherentes.", correct: true },
      { id: "b", text: "Como dos unidades base adicionales.", misconception: "Amplía incorrectamente a nueve el número de unidades base." },
      { id: "c", text: "Como unidades sin relación con el SI.", misconception: "Excluye unidades que pertenecen al sistema vigente." },
      { id: "d", text: "Como prefijos para potencias de diez.", misconception: "Confunde símbolos de unidades con prefijos." },
      { id: "e", text: "Como unidades fundamentales de longitud.", misconception: "Confunde una razón geométrica con una unidad de longitud." },
    ],
    socraticCategory: "Revisión histórica",
    socratic: "¿La expresión longitud de arco dividida para radio introduce una nueva dimensión fundamental o relaciona magnitudes de la misma dimensión?",
    explanation: "En la clasificación vigente, rad y sr son unidades derivadas coherentes. «Unidades complementarias» es una denominación histórica todavía presente en algunos materiales.",
  },
  {
    id: "M1-Q4",
    mission: 1,
    title: "El código del símbolo",
    level: "Inicial",
    task: "Escritura del SI",
    objective: "Aplicar reglas tipográficas de símbolos",
    prompt: "¿Cuál escritura respeta las convenciones del SI para una masa de veinticinco kilogramos?",
    evidence: { reading: "25 ___", note: "El símbolo es invariable y se separa del valor numérico." },
    options: [
      { id: "a", text: "25 kg", correct: true },
      { id: "b", text: "25kg", misconception: "Omite el espacio entre el valor numérico y el símbolo." },
      { id: "c", text: "25 kgs", misconception: "Pluraliza un símbolo de unidad." },
      { id: "d", text: "25 Kg", misconception: "Cambia incorrectamente la mayúscula del símbolo." },
      { id: "e", text: "25 kg.", misconception: "Añade un punto al símbolo fuera del cierre de una oración." },
    ],
    socraticCategory: "Comprobación de reglas",
    socratic: "¿Los símbolos del SI funcionan como abreviaturas que se pluralizan y puntúan, o como códigos internacionales invariantes?",
    explanation: "Se escribe 25 kg: existe un espacio entre número y símbolo, kg permanece en minúsculas, no se pluraliza y no lleva punto por sí mismo.",
  },
  {
    id: "M1-Q5",
    mission: 1,
    title: "La fuerza reconstruida",
    level: "Medio",
    task: "Unidad derivada",
    objective: "Relacionar una unidad derivada con unidades base",
    prompt: "¿Cuál expresión corresponde correctamente al newton, unidad SI de fuerza?",
    evidence: { reading: "F = m · a", note: "Combine las dimensiones de masa y aceleración." },
    options: [
      { id: "a", text: "N = kg·m·s⁻²", correct: true },
      { id: "b", text: "N = kg·m·s⁻¹", misconception: "Utiliza la dimensión de velocidad en lugar de aceleración." },
      { id: "c", text: "N = kg·m²·s⁻²", misconception: "Confunde fuerza con energía." },
      { id: "d", text: "N = g·cm·s⁻²", misconception: "Expresa la combinación en unidades C.G.S., no en unidades base SI." },
      { id: "e", text: "N = m·s⁻²", misconception: "Omite la dimensión de masa en la fuerza." },
    ],
    socraticCategory: "Razones y evidencia",
    socratic: "Si la fuerza se obtiene multiplicando masa por aceleración, ¿qué unidad aporta cada factor y cómo se combinan?",
    explanation: "F = m·a. En el SI, la masa se expresa en kg y la aceleración en m·s⁻²; por ello, N = kg·m·s⁻².",
  },
  {
    id: "M2-Q1",
    mission: 2,
    title: "Una distancia continental",
    level: "Inicial",
    task: "Notación científica",
    objective: "Expresar una cantidad grande mediante potencia de diez",
    prompt: "¿Cuál es la notación científica normalizada de 3 700 000 m?",
    evidence: { reading: "3 700 000 m", note: "Use un coeficiente cuyo valor absoluto sea al menos 1 y menor que 10." },
    options: [
      { id: "a", text: "3.7 × 10⁶ m", correct: true },
      { id: "b", text: "37 × 10⁵ m", misconception: "Conserva el valor, pero no normaliza el coeficiente." },
      { id: "c", text: "3.7 × 10⁻⁶ m", misconception: "Invierte el signo del exponente para una cantidad grande." },
      { id: "d", text: "0.37 × 10⁷ m", misconception: "Conserva el valor, pero usa un coeficiente menor que uno." },
      { id: "e", text: "3.7 × 10⁷ m", misconception: "Desplaza una posición adicional y cambia el valor por un factor diez." },
    ],
    socraticCategory: "Comprobación del procedimiento",
    socratic: "¿Cuántas posiciones debe desplazarse el separador decimal para obtener un coeficiente entre 1 y 10, y qué signo debe tener el exponente?",
    explanation: "El separador se desplaza seis posiciones hacia la izquierda: 3 700 000 m = 3.7 × 10⁶ m.",
  },
  {
    id: "M2-Q2",
    mission: 2,
    title: "Una escala microscópica",
    level: "Inicial",
    task: "Notación científica",
    objective: "Expresar una cantidad pequeña mediante potencia de diez",
    prompt: "¿Cuál es la notación científica normalizada de 0.000056 s?",
    evidence: { reading: "0.000056 s", note: "El exponente debe representar un valor menor que la unidad." },
    options: [
      { id: "a", text: "5.6 × 10⁻⁵ s", correct: true },
      { id: "b", text: "5.6 × 10⁵ s", misconception: "Usa exponente positivo para una cantidad menor que uno." },
      { id: "c", text: "56 × 10⁻⁶ s", misconception: "Conserva el valor, pero no normaliza el coeficiente." },
      { id: "d", text: "0.56 × 10⁻⁴ s", misconception: "Conserva el valor, pero usa un coeficiente menor que uno." },
      { id: "e", text: "5.6 × 10⁻⁴ s", misconception: "Desplaza una posición menos y cambia el valor por un factor diez." },
    ],
    socraticCategory: "Orden de magnitud",
    socratic: "Antes de calcular, ¿el resultado debe ser mayor o menor que 1? ¿Qué implica eso para el signo del exponente?",
    explanation: "El separador se desplaza cinco posiciones hacia la derecha para obtener 5.6; por eso el exponente es −5.",
  },
  {
    id: "M2-Q3",
    mission: 2,
    title: "La señal micro",
    level: "Inicial",
    task: "Prefijos del SI",
    objective: "Interpretar el prefijo micro",
    prompt: "¿Qué factor representa el prefijo micro, cuyo símbolo es µ?",
    evidence: { reading: "µs · µm · µA", note: "El mismo prefijo conserva su factor al combinarse con distintas unidades." },
    options: [
      { id: "a", text: "10⁻⁶", correct: true },
      { id: "b", text: "10⁻³", misconception: "Confunde micro con mili." },
      { id: "c", text: "10⁻⁹", misconception: "Confunde micro con nano." },
      { id: "d", text: "10⁶", misconception: "Invierte el orden de magnitud del prefijo." },
      { id: "e", text: "10³", misconception: "Confunde micro con kilo." },
    ],
    socraticCategory: "Relación símbolo-factor",
    socratic: "¿Micro describe un múltiplo mayor que la unidad o una millonésima parte de ella? ¿Cómo se representa una millonésima como potencia de diez?",
    explanation: "Micro representa 10⁻⁶, es decir, una millonésima parte de la unidad.",
  },
  {
    id: "M2-Q4",
    mission: 2,
    title: "Del kilómetro al metro",
    level: "Medio",
    task: "Conversión con prefijos",
    objective: "Aplicar el factor asociado con kilo",
    prompt: "¿Qué valor en metros representa exactamente una longitud de 4.2 km?",
    evidence: { reading: "4.2 km → ? m", note: "kilo representa 10³." },
    options: [
      { id: "a", text: "4200 m", correct: true },
      { id: "b", text: "0.0042 m", misconception: "Invierte el factor de conversión." },
      { id: "c", text: "42 m", misconception: "Aplica un factor diez en lugar de mil." },
      { id: "d", text: "420 m", misconception: "Aplica un factor cien en lugar de mil." },
      { id: "e", text: "4 200 000 m", misconception: "Aplica dos veces el factor del prefijo." },
    ],
    socraticCategory: "Estimación",
    socratic: "Un kilómetro contiene mil metros. Al expresar la misma longitud en una unidad más pequeña, ¿el valor numérico debería aumentar o disminuir?",
    explanation: "Como 1 km = 1000 m, entonces 4.2 km × 1000 m/km = 4200 m.",
  },
  {
    id: "M2-Q5",
    mission: 2,
    title: "El área no escala linealmente",
    level: "Medio",
    task: "Conversión de unidades de área",
    objective: "Elevar el factor de conversión completo al cuadrado",
    prompt: "¿Cuál equivalencia convierte correctamente un centímetro cuadrado, 1 cm², a metros cuadrados?",
    evidence: { reading: "1 cm² = ? m²", note: "Como 1 cm = 10⁻² m, el factor completo debe elevarse al cuadrado." },
    options: [
      { id: "a", text: "1 × 10⁻⁴ m²", correct: true },
      { id: "b", text: "1 × 10⁻² m²", misconception: "Aplica el factor lineal sin elevarlo al cuadrado." },
      { id: "c", text: "1 × 10⁻⁶ m²", misconception: "Eleva el factor como si se tratara de una unidad de volumen." },
      { id: "d", text: "100 m²", misconception: "Invierte la dirección del factor y no considera el cuadrado." },
      { id: "e", text: "0.1 m²", misconception: "Mueve el separador decimal sin construir un factor de conversión válido." },
    ],
    socraticCategory: "Escala geométrica",
    socratic: "Si cada lado de un cuadrado mide 10⁻² metros, ¿qué potencia aparece al multiplicar lado por lado para obtener su área?",
    explanation: "Un centímetro cuadrado equivale a (10⁻² m)². Por tanto, 1 cm² = 10⁻⁴ m²; el exponente del factor también se multiplica por dos.",
  },
  {
    id: "M3-Q1",
    mission: 3,
    title: "Los ceros que informan",
    level: "Inicial",
    task: "Conteo de cifras significativas",
    objective: "Interpretar ceros iniciales y finales",
    prompt: "¿Cuántas cifras significativas contiene la medición 0.00340 m?",
    evidence: { reading: "0.00340 m", note: "Los ceros iniciales ubican el separador; el cero final expresa precisión." },
    options: [
      { id: "a", text: "3 cifras significativas", correct: true },
      { id: "b", text: "2 cifras significativas", misconception: "Elimina el cero final aunque existe decimal explícito." },
      { id: "c", text: "4 cifras significativas", misconception: "Cuenta uno de los ceros iniciales." },
      { id: "d", text: "5 cifras significativas", misconception: "Cuenta todos los ceros de la escritura." },
      { id: "e", text: "6 cifras significativas", misconception: "Cuenta todos los caracteres numéricos como información de precisión." },
    ],
    socraticCategory: "Información de los dígitos",
    socratic: "¿Qué ceros solo ubican el separador decimal y cuál cero comunica hasta qué posición se reportó la medición?",
    explanation: "Las cifras significativas son 3, 4 y el cero final: en total, 3. Los ceros iniciales no cuentan.",
  },
  {
    id: "M3-Q2",
    mission: 3,
    title: "La regla no inventa dígitos",
    level: "Medio",
    task: "Resolución instrumental",
    objective: "Relacionar precisión reportada con resolución",
    prompt: "Una regla permite justificar una lectura de 12.3 cm. ¿Cuál reporte evita inventar una precisión que el instrumento no ofrece?",
    evidence: { reading: "12.3 cm", note: "Lectura defendible según la escala disponible.", scale: ["12.0", "12.1", "12.2", "12.3", "12.4"] },
    options: [
      { id: "a", text: "12.3 cm", correct: true },
      { id: "b", text: "12.300000 cm", misconception: "Supone que agregar decimales aumenta la precisión." },
      { id: "c", text: "12 cm", misconception: "Elimina información que la lectura sí permite defender." },
      { id: "d", text: "12.345 cm", misconception: "Añade cifras que no proceden de la resolución observada." },
      { id: "e", text: "120.3 cm", misconception: "Cambia el orden de magnitud en lugar de reportar precisión." },
    ],
    socraticCategory: "Calidad de la evidencia",
    socratic: "¿De dónde procede cada dígito escrito? Si la escala no permite observarlo, ¿qué evidencia justificaría conservarlo?",
    explanation: "El resultado debe reflejar la capacidad real de discriminación del instrumento. Añadir ceros o cifras no observadas no crea precisión.",
  },
  {
    id: "M3-Q3",
    mission: 3,
    title: "La suma limitada",
    level: "Medio",
    task: "Suma con precisión decimal",
    objective: "Aplicar la regla de suma y resta",
    prompt: "Aplicando la regla de precisión decimal, ¿cómo debe reportarse 12.34 cm + 0.5 cm?",
    evidence: { reading: "12.34 cm + 0.5 cm", note: "El término menos preciso llega hasta las décimas." },
    options: [
      { id: "a", text: "12.8 cm", correct: true },
      { id: "b", text: "12.84 cm", misconception: "Conserva más decimales de los que permite el término menos preciso." },
      { id: "c", text: "13 cm", misconception: "Redondea hasta unidades y elimina información defendible." },
      { id: "d", text: "12.840 cm", misconception: "Añade un cero y aparenta todavía mayor precisión." },
      { id: "e", text: "12.3 cm", misconception: "Redondea antes de completar correctamente la operación." },
    ],
    socraticCategory: "Procedimiento y límite",
    socratic: "¿Cuál sumando llega a la posición decimal menos precisa y qué posición puede conservar razonablemente el resultado?",
    explanation: "La suma exacta es 12.84 cm, pero 0.5 cm solo informa décimas. El resultado se redondea a 12.8 cm.",
  },
  {
    id: "M3-Q4",
    mission: 3,
    title: "El cociente defendible",
    level: "Medio",
    task: "División con cifras significativas",
    objective: "Aplicar la regla de multiplicación y división",
    prompt: "¿Cómo debe reportarse 4.897 ÷ 2.08 aplicando cifras significativas?",
    evidence: { reading: "4.897 ÷ 2.08 = 2.3543…", note: "El factor con menor precisión tiene 3 cifras significativas." },
    options: [
      { id: "a", text: "2.35", correct: true },
      { id: "b", text: "2.3543", misconception: "Conserva todos los dígitos producidos por la calculadora." },
      { id: "c", text: "2.4", misconception: "Reduce a dos cifras significativas sin que los datos lo exijan." },
      { id: "d", text: "2.354", misconception: "Usa las cuatro cifras del numerador e ignora el factor limitante." },
      { id: "e", text: "2", misconception: "Redondea hasta una sola cifra significativa y pierde información." },
    ],
    socraticCategory: "Trazabilidad de la precisión",
    socratic: "¿Cuál de los dos datos limita la cantidad de cifras significativas que puede defender el cociente?",
    explanation: "2.08 tiene 3 cifras significativas, menos que 4.897. El cociente debe reportarse con 3 cifras significativas: 2.35.",
  },
  {
    id: "M3-Q5",
    mission: 3,
    title: "Precisa, pero desplazada",
    level: "Medio",
    task: "Precisión y exactitud",
    objective: "Distinguir la dispersión de la cercanía al valor de referencia",
    prompt: "Un sensor registra 9.81, 9.81, 9.82 y 9.81 m/s², pero el valor de referencia es 10.20 m/s². ¿Cuál interpretación es correcta?",
    evidence: { reading: "9.81 · 9.81 · 9.82 · 9.81 m/s²", note: "Valor de referencia: 10.20 m/s²." },
    options: [
      { id: "a", text: "Las mediciones son precisas entre sí, pero poco exactas respecto al valor de referencia.", correct: true },
      { id: "b", text: "Las mediciones son exactas porque tienen dos cifras decimales.", misconception: "Confunde cantidad de decimales con exactitud." },
      { id: "c", text: "Las mediciones son poco precisas porque no coinciden con el valor de referencia.", misconception: "Confunde precisión, asociada con dispersión, con exactitud respecto a la referencia." },
      { id: "d", text: "Las mediciones son exactas y precisas porque casi se repiten.", misconception: "La repetibilidad por sí sola no garantiza cercanía al valor de referencia." },
      { id: "e", text: "No es posible evaluar ni precisión ni exactitud con esos datos.", misconception: "Ignora que la serie permite valorar dispersión y que se proporciona una referencia." },
    ],
    socraticCategory: "Comparación de criterios",
    socratic: "¿Las lecturas están dispersas entre sí? ¿Qué tan cerca se encuentran del valor de referencia? Responde cada pregunta por separado.",
    explanation: "Las lecturas presentan poca dispersión y, por ello, son precisas entre sí. Sin embargo, están alejadas de 10.20 m/s², de modo que son poco exactas respecto a la referencia.",
  },
  {
    id: "M4-Q1",
    mission: 4,
    title: "La escala con origen desplazado",
    level: "Medio",
    task: "Conversión de temperatura",
    objective: "Reconocer una conversión que cambia escala y origen",
    prompt: "¿Cuál conversión expresa correctamente una temperatura de 20 grados Celsius, 20 °C, en grados Fahrenheit?",
    evidence: { reading: "°F = (9/5)·°C + 32", note: "La escala cambia tanto el tamaño del grado como el origen." },
    options: [
      { id: "a", text: "68 °F", correct: true },
      { id: "b", text: "36 °F", misconception: "Multiplica por 9/5, pero omite el desplazamiento de 32 grados." },
      { id: "c", text: "52 °F", misconception: "Suma 32, pero omite el cambio de escala por 9/5." },
      { id: "d", text: "−6.7 °F", misconception: "Aplica en sentido incorrecto la fórmula inversa." },
      { id: "e", text: "20 °F", misconception: "Conserva el valor numérico aunque las escalas no comparten el mismo origen." },
    ],
    socraticCategory: "Origen y escala",
    socratic: "Si 0 °C corresponde a 32 °F, ¿basta con multiplicar para convertir la temperatura o también debe considerarse el origen desplazado?",
    explanation: "La conversión es °F = (9/5)·°C + 32. Para 20 °C: (9/5)·20 + 32 = 36 + 32 = 68 °F. No es una conversión puramente multiplicativa.",
  },
  {
    id: "M4-Q2",
    mission: 4,
    title: "La firma de la velocidad",
    level: "Inicial",
    task: "Dimensiones fundamentales",
    objective: "Identificar la dimensión de velocidad",
    prompt: "¿Cuál es la dimensión de la velocidad lineal?",
    evidence: { reading: "v = Δx / Δt", note: "Longitud dividida para tiempo." },
    options: [
      { id: "a", text: "[L·T⁻¹]", correct: true },
      { id: "b", text: "[L·T⁻²]", misconception: "Confunde velocidad con aceleración." },
      { id: "c", text: "[M·L·T⁻¹]", misconception: "Incluye masa y obtiene la dimensión de cantidad de movimiento." },
      { id: "d", text: "[L²·T⁻¹]", misconception: "Eleva incorrectamente la dimensión de longitud." },
      { id: "e", text: "[T·L⁻¹]", misconception: "Invierte la razón entre longitud y tiempo." },
    ],
    socraticCategory: "Traducción algebraica",
    socratic: "Si la velocidad es cambio de posición dividido para tiempo, ¿en qué lugar de la expresión dimensional debe aparecer cada magnitud?",
    explanation: "La posición tiene dimensión [L] y el tiempo [T]. Al dividir, [v] = [L]/[T] = [L·T⁻¹].",
  },
  {
    id: "M4-Q3",
    mission: 4,
    title: "Tres términos compatibles",
    level: "Medio",
    task: "Homogeneidad dimensional",
    objective: "Verificar dimensiones en una ecuación",
    prompt: "¿Cuál expresión es dimensionalmente homogénea para representar un desplazamiento Δx?",
    evidence: { reading: "[Δx] = [L]", note: "Todos los términos que se suman deben tener dimensión de longitud." },
    options: [
      { id: "a", text: "Δx = v₀t + ½at²", correct: true },
      { id: "b", text: "Δx = v₀ + at²", misconception: "Suma velocidad y longitud." },
      { id: "c", text: "Δx = v₀t + ½at", misconception: "El segundo término tiene dimensión de velocidad." },
      { id: "d", text: "Δx = v₀/t + ½at²", misconception: "El primer término tiene dimensión de aceleración." },
      { id: "e", text: "Δx = v₀t² + ½a", misconception: "Ningún término coincide necesariamente con longitud." },
    ],
    socraticCategory: "Comparación de términos",
    socratic: "¿Qué dimensión adquiere v₀t? ¿Qué dimensión adquiere at²? ¿Pueden sumarse entre sí y compararse con Δx?",
    explanation: "[v₀t] = [L·T⁻¹][T] = [L] y [at²] = [L·T⁻²][T²] = [L]. Los tres términos son homogéneos.",
  },
  {
    id: "M4-Q4",
    mission: 4,
    title: "La condición que no demuestra todo",
    level: "Alto",
    task: "Alcance del análisis dimensional",
    objective: "Reconocer los límites de la homogeneidad",
    prompt: "Una ecuación es dimensionalmente homogénea. ¿Qué conclusión está justificada?",
    evidence: { reading: "[lado izquierdo] = [lado derecho]", note: "La prueba dimensional examina coherencia, no toda la física del modelo." },
    options: [
      { id: "a", text: "Supera una condición necesaria, pero todavía podría ser físicamente incorrecta.", correct: true },
      { id: "b", text: "La ecuación queda demostrada como físicamente correcta.", misconception: "Considera la homogeneidad como condición suficiente." },
      { id: "c", text: "Todos sus valores numéricos son necesariamente exactos.", misconception: "Confunde coherencia dimensional con exactitud de los datos." },
      { id: "d", text: "La ecuación solo puede utilizar unidades del SI.", misconception: "Confunde dimensiones con un sistema específico de unidades." },
      { id: "e", text: "La ecuación no necesita evidencia experimental.", misconception: "Sustituye la validación física por una comprobación formal." },
    ],
    socraticCategory: "Implicaciones y límites",
    socratic: "¿Podrían existir dos ecuaciones distintas con las mismas dimensiones, aunque solo una describa correctamente el fenómeno?",
    explanation: "La homogeneidad dimensional es necesaria, pero no suficiente. No determina coeficientes adimensionales ni garantiza que el modelo represente la física real.",
  },
  {
    id: "M4-Q5",
    mission: 4,
    title: "Factores orientados",
    level: "Alto",
    task: "Diseño de una conversión",
    objective: "Orientar factores para cancelar unidades",
    prompt: "¿Qué cadena convierte correctamente 72 km/h a m/s y permite cancelar las unidades?",
    evidence: { reading: "72 km/h", note: "Cada factor de conversión debe ser equivalente a uno." },
    options: [
      { id: "a", text: "72 km/h × (1000 m/1 km) × (1 h/3600 s) = 20 m/s", correct: true },
      { id: "b", text: "72 km/h × (1 km/1000 m) × (3600 s/1 h)", misconception: "Orienta ambos factores en sentido contrario y no cancela las unidades buscadas." },
      { id: "c", text: "72 km/h × (1000 m/1 km) × (3600 s/1 h)", misconception: "Orienta incorrectamente el factor temporal." },
      { id: "d", text: "72 km/h × (1 m/1000 km) × (1 s/3600 h)", misconception: "Utiliza razones que no representan equivalencias correctas." },
      { id: "e", text: "72 km/h ÷ 1000 ÷ 3600 = 0.00002 m/s", misconception: "Aplica operaciones numéricas sin rastrear la cancelación de unidades." },
    ],
    socraticCategory: "Auditoría de unidades",
    socratic: "Escribe las unidades como factores algebraicos: ¿qué debe aparecer arriba o abajo para cancelar km y h y dejar m/s?",
    explanation: "La orientación correcta es 1000 m/1 km y 1 h/3600 s. Así se cancelan km y h, y 72/3.6 = 20 m/s.",
  },
];

const defaultSettings = {
  music: true,
  musicVolume: 0.25,
  narration: true,
  narrationVolume: 0.9,
  narrationRate: 1,
  contrastLevel: 0,
  textScale: 100,
};

function freshState() {
  return {
    version: 2,
    screen: "landing",
    teamName: "",
    players: [""],
    avatars: [0],
    currentMission: 0,
    questionIndex: 0,
    score: 0,
    missionScores: [0, 0, 0, 0],
    completedMissions: [],
    badges: [],
    answers: [],
    attempt: 1,
    phase: "answering",
    selectedOptionId: null,
    attemptedOptionIds: [],
    lastFeedback: null,
    sessionSeed: Math.floor(Math.random() * 2_147_483_647),
    startedAt: null,
    endedAt: null,
  };
}

let state = freshState();
let settings = { ...defaultSettings };
let savedCandidate = null;
let timerHandle = null;
let toastHandle = null;

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function avatarMarkup(index, className = "avatar-image") {
  const avatar = AVATARS[index] || AVATARS[0];
  return `<img class="${className}" src="${avatar.image}" alt="${escapeHtml(avatar.name)}" />`;
}

function badgeMarkup(index, className = "badge-image", decorative = false) {
  const mission = MISSIONS[index] || MISSIONS[0];
  return `<img class="${className}" src="${mission.badgeImage}" alt="${decorative ? "" : escapeHtml(`Insignia ${mission.badge}`)}" />`;
}

function assetAbsoluteUrl(path) {
  return new URL(path, window.location.href).href;
}

function safeJsonParse(value) {
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}

// En navegadores que bloquean el almacenamiento, la actividad sigue en memoria.
const sessionMemory = new Map();
let storageUnavailable = false;
function storageAction(action, key, value) {
  if (action === "setItem") sessionMemory.set(key, value);
  if (action === "removeItem") sessionMemory.delete(key);
  try {
    const result = action === "setItem" ? localStorage.setItem(key, value) : localStorage[action](key);
    return result;
  } catch {
    storageUnavailable = true;
    if (typeof document !== "undefined") {
      const notice = document.querySelector("#storage-notice");
      if (notice) notice.hidden = false;
    }
    return action === "getItem" ? sessionMemory.get(key) ?? null : undefined;
  }
}

function loadLocalData() {
  const savedSettings = safeJsonParse(storageAction("getItem", SETTINGS_KEY));
  if (savedSettings) {
    settings = { ...defaultSettings, ...savedSettings };
    if (!Number.isFinite(settings.contrastLevel)) settings.contrastLevel = savedSettings.highContrast ? 100 : 0;
    if (!Number.isFinite(settings.textScale)) settings.textScale = savedSettings.largeText ? 118 : 100;
  }
  const candidate = safeJsonParse(storageAction("getItem", STORAGE_KEY));
  if (candidate && candidate.version === 2 && Array.isArray(candidate.answers)) savedCandidate = candidate;
}

function saveState() {
  storageAction("setItem", STORAGE_KEY, JSON.stringify(state));
}

function saveSettings() {
  storageAction("setItem", SETTINGS_KEY, JSON.stringify(settings));
}

function seededRandom(seed) {
  let value = seed >>> 0;
  return () => {
    value += 0x6d2b79f5;
    let result = value;
    result = Math.imul(result ^ (result >>> 15), result | 1);
    result ^= result + Math.imul(result ^ (result >>> 7), result | 61);
    return ((result ^ (result >>> 14)) >>> 0) / 4_294_967_296;
  };
}

function shuffled(values, random) {
  const result = [...values];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(random() * (index + 1));
    [result[index], result[swapIndex]] = [result[swapIndex], result[index]];
  }
  return result;
}

function buildCorrectLetterSchedule(seed) {
  const random = seededRandom(seed + 9719);
  const pool = LETTERS.flatMap((letter) => Array.from({ length: 4 }, () => letter));
  for (let attempt = 0; attempt < 300; attempt += 1) {
    const candidate = shuffled(pool, random);
    const noAdjacent = candidate.every((letter, index) => index === 0 || letter !== candidate[index - 1]);
    const noSimpleCycle = candidate.some((letter, index) => index >= 5 && letter !== candidate[index % 5]);
    if (noAdjacent && noSimpleCycle) return candidate;
  }
  return ["A", "C", "E", "B", "D", "C", "A", "D", "B", "E", "D", "A", "E", "C", "B", "E", "B", "D", "A", "C"];
}

function getQuestionOptions(question, globalIndex) {
  const targetLetter = buildCorrectLetterSchedule(state.sessionSeed)[globalIndex];
  const targetIndex = LETTERS.indexOf(targetLetter);
  const correct = question.options.find((option) => option.correct);
  const distractors = shuffled(
    question.options.filter((option) => !option.correct),
    seededRandom(state.sessionSeed + globalIndex * 7919 + 113),
  );
  const ordered = [];
  let distractorIndex = 0;
  LETTERS.forEach((_, index) => {
    ordered.push(index === targetIndex ? correct : distractors[distractorIndex++]);
  });
  return ordered;
}

class AmbientAudio {
  constructor() {
    this.context = null;
    this.effectGain = null;
    this.unlocked = false;
    this.activeTrack = null;
    this.tracks = typeof Audio === "undefined" ? {} : {
      mystery: new Audio("assets/audio/misterio.wav"),
      motivation: new Audio("assets/audio/motivacion.wav"),
    };
    Object.values(this.tracks).forEach((track) => {
      track.loop = true;
      track.preload = "auto";
      track.volume = settings.musicVolume;
    });
  }

  unlock() {
    this.unlocked = true;
    if ((window.AudioContext || window.webkitAudioContext) && !this.context) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      this.context = new AudioContextClass();
      const master = this.context.createGain();
      master.gain.value = 0.5;
      master.connect(this.context.destination);
      this.effectGain = this.context.createGain();
      this.effectGain.gain.value = 0.16;
      this.effectGain.connect(master);
    }
    if (this.context?.state === "suspended") this.context.resume();
    this.syncTrack(state.screen);
  }

  trackForScreen(screen) {
    if (screen === "landing") return null;
    if (screen === "final") return "motivation";
    return "mystery";
  }

  syncTrack(screen) {
    const nextTrack = this.trackForScreen(screen);
    const previousTrack = this.activeTrack;
    Object.entries(this.tracks).forEach(([key, track]) => {
      track.volume = settings.musicVolume;
      if (key !== nextTrack) track.pause();
      if (key === nextTrack && key !== previousTrack) track.currentTime = 0;
    });
    this.activeTrack = nextTrack;
    this.updateMusic();
  }

  updateMusic() {
    Object.values(this.tracks).forEach((track) => { track.volume = settings.musicVolume; });
    const track = this.tracks[this.activeTrack];
    if (!track) return;
    if (!settings.music || !this.unlocked) {
      track.pause();
      return;
    }
    track.play().catch(() => {
      showToast("Presiona una vez la pantalla para activar la música ambiental.");
    });
  }

  effect(kind) {
    if (!this.context || !this.effectGain) return;
    const now = this.context.currentTime;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(kind === "success" ? 520 : 210, now);
    oscillator.frequency.exponentialRampToValueAtTime(kind === "success" ? 820 : 135, now + 0.18);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.12, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.24);
    oscillator.connect(gain);
    gain.connect(this.effectGain);
    oscillator.start(now);
    oscillator.stop(now + 0.25);
  }
}

const ambientAudio = new AmbientAudio();

function narrationTextForScreen(screen) {
  if (screen === "landing") return "METRIX. El protocolo de la medida perdida. Inicia una experiencia individual para restaurar la coherencia de las mediciones.";
  if (screen === "setup") return "Registra tu nombre y selecciona el avatar que utilizarás durante la experiencia.";
  if (screen === "briefing") return "El protocolo contiene cuatro misiones y veinte desafíos. La primera respuesta correcta vale dos puntos. Después de un error, el segundo intento vale un punto.";
  if (screen === "map") return `Mapa de misiones. ${state.teamName || "El participante"} tiene ${state.score} puntos.`;
  if (screen === "missionIntro") {
    const mission = MISSIONS[state.currentMission];
    return `${mission.title}. ${mission.narrative} Objetivo. ${mission.objective}`;
  }
  if (screen === "question") {
    const question = currentQuestion();
    return `${question.title}. ${question.prompt}`;
  }
  if (screen === "missionComplete") {
    const mission = MISSIONS[state.currentMission];
    return `${mission.title} completada. Puntaje ${state.missionScores[state.currentMission]} de 10.`;
  }
  if (screen === "final") return `Protocolo completado. Puntaje total ${state.score} de 40 puntos. La coherencia ha sido restaurada.`;
  return "";
}

function chooseSpanishVoice() {
  const voices = window.speechSynthesis?.getVoices?.() || [];
  const preferredNames = /(Paulina|M[oó]nica|Sabina|Jorge|Diego|Helena|Google|Microsoft|Natural|Neural)/i;
  return voices
    .filter((voice) => /^es/i.test(voice.lang))
    .map((voice) => {
      let score = 0;
      if (/^es-EC$/i.test(voice.lang)) score += 100;
      else if (/^es-419$/i.test(voice.lang)) score += 90;
      else if (/^es-(MX|CO|PE|CL|AR)$/i.test(voice.lang)) score += 75;
      else if (/^es-ES$/i.test(voice.lang)) score += 65;
      if (preferredNames.test(voice.name)) score += 25;
      if (voice.localService) score += 8;
      if (voice.default) score += 4;
      return { voice, score };
    })
    .sort((a, b) => b.score - a.score)[0]?.voice || null;
}

function naturalizeSpeechText(text) {
  return String(text)
    .replace(/\bgrados?\s+cent[ií]grados?\b/gi, "grados Celsius")
    .replace(/(\d+(?:[.,]\d+)?)\s*°\s*C\b/gi, "$1 grados Celsius")
    .replace(/°\s*C\b/gi, "grados Celsius")
    .replace(/\bSI\b/g, "Sistema Internacional")
    .replace(/\bPX\b/g, "puntos")
    .replace(/µ/g, " micro ")
    .replace(/×/g, " por ")
    .replace(/·/g, " por ")
    .replace(/⁻⁶/g, " elevado a menos seis ")
    .replace(/⁻⁵/g, " elevado a menos cinco ")
    .replace(/⁻⁴/g, " elevado a menos cuatro ")
    .replace(/⁻³/g, " elevado a menos tres ")
    .replace(/⁻²/g, " elevado a menos dos ")
    .replace(/⁻¹/g, " elevado a menos uno ")
    .replace(/²/g, " al cuadrado ")
    .replace(/³/g, " al cubo ")
    .replace(/\s+/g, " ")
    .trim();
}

function speechChunks(text, limit = 180) {
  const sentences = naturalizeSpeechText(text).match(/[^.!?;:]+[.!?;:]?/g) || [text];
  const chunks = [];
  let current = "";
  sentences.forEach((sentence) => {
    const candidate = `${current} ${sentence.trim()}`.trim();
    if (candidate.length <= limit) {
      current = candidate;
      return;
    }
    if (current) chunks.push(current);
    current = sentence.trim();
  });
  if (current) chunks.push(current);
  return chunks;
}

let narrationGeneration = 0;

function speak(text, interrupt = true) {
  if (!settings.narration || !window.speechSynthesis || !text) return;
  if (interrupt) {
    narrationGeneration += 1;
    window.speechSynthesis.cancel();
  }
  const generation = narrationGeneration;
  const voice = chooseSpanishVoice();
  const chunks = speechChunks(text);
  const speakNext = (index) => {
    if (generation !== narrationGeneration || !settings.narration) return;
    if (index >= chunks.length) {
      $("#narration-status").textContent = "Narración disponible";
      return;
    }
    const utterance = new SpeechSynthesisUtterance(chunks[index]);
    if (voice) utterance.voice = voice;
    utterance.lang = voice?.lang || "es-EC";
    utterance.volume = settings.narrationVolume;
    utterance.rate = settings.narrationRate;
    utterance.pitch = 1.02;
    utterance.onstart = () => { $("#narration-status").textContent = "Narración en curso"; };
    utterance.onend = () => speakNext(index + 1);
    utterance.onerror = () => { $("#narration-status").textContent = "La voz del dispositivo no está disponible"; };
    window.speechSynthesis.speak(utterance);
  };
  speakNext(0);
}

function applySettings() {
  settings.contrastLevel = Math.min(100, Math.max(0, Number(settings.contrastLevel) || 0));
  settings.textScale = Math.min(130, Math.max(90, Number(settings.textScale) || 100));
  document.documentElement.style.fontSize = `${settings.textScale}%`;
  document.documentElement.style.setProperty("--ui-contrast", String(1 + settings.contrastLevel * 0.005));
  document.body.classList.toggle("high-contrast", settings.contrastLevel >= 50);
  ambientAudio.updateMusic();

  $("#music-toggle").setAttribute("aria-pressed", String(settings.music));
  $("#music-toggle").textContent = settings.music ? "ACTIVA" : "INACTIVA";
  $("#narration-toggle").setAttribute("aria-pressed", String(settings.narration));
  $("#narration-toggle").textContent = settings.narration ? "ACTIVA" : "INACTIVA";
  if (!settings.narration) $("#narration-status").textContent = "Narración desactivada";
  $("#music-volume").value = settings.musicVolume;
  $("#music-volume-output").textContent = `${Math.round(settings.musicVolume * 100)}%`;
  $("#narration-volume").value = settings.narrationVolume;
  $("#narration-volume-output").textContent = `${Math.round(settings.narrationVolume * 100)}%`;
  $("#narration-rate").value = settings.narrationRate;
  $("#narration-rate-output").textContent = `${String(settings.narrationRate).replace(".", ",")}×`;
  const contrastActive = settings.contrastLevel >= 50;
  $("#contrast-toggle").setAttribute("aria-pressed", String(contrastActive));
  $("#contrast-toggle").textContent = contrastActive ? "ACTIVO" : "INACTIVO";
  const enlargedText = settings.textScale > 100;
  $("#text-toggle").setAttribute("aria-pressed", String(enlargedText));
  $("#text-toggle").textContent = enlargedText ? `ACTIVO · ${settings.textScale}%` : "INACTIVO · 100%";
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("is-visible");
  clearTimeout(toastHandle);
  toastHandle = setTimeout(() => toast.classList.remove("is-visible"), 3300);
}

function setScreen(screen, { narrate = true } = {}) {
  state.screen = screen;
  ambientAudio.syncTrack(screen);
  $$(".screen").forEach((element) => element.classList.toggle("is-active", element.dataset.screen === screen));
  renderScreen(screen);
  updateHud();
  saveState();
  window.scrollTo({ top: 0, behavior: "smooth" });
  $("#main-content").focus({ preventScroll: true });
  if (narrate) setTimeout(() => speak(narrationTextForScreen(screen)), 180);
}

function renderScreen(screen) {
  if (screen === "setup") renderSetup();
  if (screen === "briefing") renderBriefing();
  if (screen === "map") renderMap();
  if (screen === "missionIntro") renderMissionIntro();
  if (screen === "question") renderQuestion();
  if (screen === "missionComplete") renderMissionComplete();
  if (screen === "final") renderFinal();
}

function updateHud() {
  const completed = state.answers.length;
  $("#hud-score").textContent = state.score;
  $("#hud-progress-label").textContent = `${completed}/20`;
  $("#hud-progress-bar").style.width = `${(completed / 20) * 100}%`;
  $("#landing-coherence").textContent = `${((completed / 20) * 100).toFixed(1)}%`;
}

function formatDuration(milliseconds) {
  const seconds = Math.max(0, Math.floor(milliseconds / 1000));
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const restSeconds = seconds % 60;
  if (hours) return `${hours} h ${String(minutes).padStart(2, "0")} min`;
  return `${minutes} min ${String(restSeconds).padStart(2, "0")} s`;
}

function updateTimer() {
  if (!state.startedAt) {
    $("#hud-time").textContent = "00:00";
    return;
  }
  const end = state.endedAt || Date.now();
  const seconds = Math.max(0, Math.floor((end - state.startedAt) / 1000));
  const minutes = Math.floor(seconds / 60);
  $("#hud-time").textContent = `${String(minutes).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
}

function renderSetup() {
  $("#team-name").value = state.teamName;
  const playerGrid = $("#player-grid");
  const selectedAvatarIndex = Number.isInteger(state.avatars[0]) ? state.avatars[0] : 0;
  const selectedAvatar = AVATARS[selectedAvatarIndex];
  const avatarButtons = AVATARS.map((avatar, avatarIndex) => {
    const selected = selectedAvatarIndex === avatarIndex;
    return `<button class="avatar-option${selected ? " is-selected" : ""}" type="button" data-avatar="${avatarIndex}" aria-label="Seleccionar avatar ${escapeHtml(avatar.name)}" aria-pressed="${selected}">${avatarMarkup(avatarIndex)}</button>`;
  }).join("");
  playerGrid.innerHTML = `
    <article class="player-card">
      <div class="player-card-head"><span>SELECCIÓN DE AVATAR</span><div class="selected-avatar" title="${escapeHtml(selectedAvatar.name)}">${avatarMarkup(selectedAvatarIndex)}</div></div>
      <p class="avatar-instruction">Presiona un avatar para seleccionarlo como tu identificador individual.</p>
      <div class="avatar-grid">${avatarButtons}</div>
    </article>`;

  $$(".avatar-option", playerGrid).forEach((button) => {
    button.addEventListener("click", () => {
      state.avatars[0] = Number(button.dataset.avatar);
      renderSetup();
    });
  });
}

function teamValidationMessage() {
  if (!state.teamName.trim()) return "Escribe tu nombre y apellido para continuar.";
  return "";
}

function renderBriefing() {
  $("#briefing-missions").innerHTML = MISSIONS.map(
    (mission) => `
      <article class="preview-mission" style="--mission-color:${mission.color}">
        <img class="preview-mission-image" src="${mission.image}" alt="" />
        <div><strong>${mission.title}</strong><small>${mission.short}</small></div>
        <em>5 DESAFÍOS</em>
      </article>`,
  ).join("");
}

function renderMap() {
  $("#map-team-name").textContent = state.teamName || "—";
  $("#map-completed").textContent = `${state.answers.length}/20`;
  $("#map-badges").textContent = `${state.badges.length}/4`;
  $("#map-score").textContent = `${state.score}/40`;
  const nextMission = state.completedMissions.length;
  $("#mission-map").innerHTML = MISSIONS.map((mission, index) => {
    const completed = state.completedMissions.includes(index);
    const available = index === nextMission;
    const missionAnswers = state.answers.filter((answer) => answer.missionIndex === index).length;
    const progress = Array.from({ length: 5 }, (_, step) => `<i class="${step < missionAnswers ? "is-done" : ""}"></i>`).join("");
    const status = completed ? `COMPLETADA · ${state.missionScores[index]}/10` : available ? "DISPONIBLE" : "BLOQUEADA";
    return `
      <button class="mission-card" type="button" style="--mission-color:${mission.color}" data-mission="${index}" ${available ? "" : "disabled"}>
        <img class="mission-card-image" src="${mission.image}" alt="" />
        <div class="mission-card-top"><span class="mission-card-symbol">${mission.symbol}</span><span class="mission-card-status">${status}</span></div>
        <h2>${mission.title}</h2>
        <p>${mission.short}</p>
        <div class="mission-card-progress" aria-label="${missionAnswers} de 5 desafíos completados">${progress}</div>
      </button>`;
  }).join("");
  $$("[data-mission]", $("#mission-map")).forEach((button) => {
    button.addEventListener("click", () => {
      state.currentMission = Number(button.dataset.mission);
      state.questionIndex = 0;
      resetQuestionState();
      setScreen("missionIntro");
    });
  });
}

function renderMissionIntro() {
  const mission = MISSIONS[state.currentMission];
  $("#screen-mission-intro").style.setProperty("--mission-color", mission.color);
  $("#mission-intro-code").textContent = mission.code;
  $("#mission-intro-title").textContent = mission.title;
  $("#mission-intro-narrative").textContent = mission.narrative;
  $("#mission-intro-objective").textContent = mission.objective;
  $("#mission-intro-image").src = mission.image;
  $("#mission-intro-image").alt = mission.imageAlt;
  $("#mission-badge-icon").src = mission.badgeImage;
  $("#mission-badge-icon").alt = `Insignia ${mission.badge}`;
  $("#mission-badge-name").textContent = mission.badge;
}

function currentGlobalQuestionIndex() {
  return state.currentMission * 5 + state.questionIndex;
}

function currentQuestion() {
  return QUESTIONS[currentGlobalQuestionIndex()];
}

function currentPlayerIndex() {
  return 0;
}

function renderEvidence(evidence) {
  const scale = evidence.scale
    ? `<div class="scale">${evidence.scale.map((label) => `<span>${label}</span>`).join("")}</div>`
    : "";
  return `<div class="evidence-display"><div class="reading ${evidence.reading.includes("[") ? "formula" : ""}">${evidence.reading}</div>${scale}<p>${evidence.note}</p></div>`;
}

function renderQuestion() {
  const question = currentQuestion();
  const mission = MISSIONS[state.currentMission];
  const globalIndex = currentGlobalQuestionIndex();
  const options = getQuestionOptions(question, globalIndex);
  const playerIndex = currentPlayerIndex();
  $("#screen-question").style.setProperty("--mission-color", mission.color);
  $("#question-mission-label").textContent = `${mission.code} · DESAFÍO ${state.questionIndex + 1}/5`;
  $("#question-title").textContent = question.title;
  $("#question-task").textContent = question.task;
  $("#question-level").textContent = question.level;
  $("#question-objective").textContent = question.objective;
  $("#question-prompt").textContent = question.prompt;
  $("#question-evidence").innerHTML = renderEvidence(question.evidence);
  $("#turn-player").textContent = state.players[playerIndex];
  $("#turn-avatar").innerHTML = avatarMarkup(state.avatars[playerIndex], "turn-avatar-image");
  $("#attempt-label").textContent = `INTENTO ${state.attempt} DE 2`;
  $("#points-available").textContent = `${state.attempt === 1 ? 2 : 1} ${state.attempt === 1 ? "PUNTOS" : "PUNTO"} DISPONIBLE${state.attempt === 1 ? "S" : ""}`;

  const optionList = $("#option-list");
  optionList.innerHTML = options
    .map((option, index) => {
      const selected = state.selectedOptionId === option.id;
      const attempted = state.attemptedOptionIds.includes(option.id);
      return `<button class="option-button${selected ? " is-selected" : ""}${attempted ? " is-attempted" : ""}" type="button" data-option="${option.id}" ${state.phase !== "answering" || attempted ? "disabled" : ""}><span class="option-letter">${LETTERS[index]}</span><span>${option.text}</span></button>`;
    })
    .join("");
  $$(".option-button", optionList).forEach((button) => {
    button.addEventListener("click", () => {
      state.selectedOptionId = button.dataset.option;
      $$(".option-button", optionList).forEach((candidate) => candidate.classList.toggle("is-selected", candidate === button));
      $("#submit-answer").disabled = false;
    });
  });
  $("#submit-answer").disabled = !state.selectedOptionId || state.phase !== "answering";
  $("#submit-answer").classList.toggle("is-hidden", state.phase !== "answering");
  renderFeedbackFromState();
}

function resetQuestionState() {
  state.attempt = 1;
  state.phase = "answering";
  state.selectedOptionId = null;
  state.attemptedOptionIds = [];
  state.lastFeedback = null;
}

function selectedOption() {
  return currentQuestion().options.find((option) => option.id === state.selectedOptionId);
}

function submitCurrentAnswer() {
  if (state.phase !== "answering" || !state.selectedOptionId) return;
  const question = currentQuestion();
  const option = selectedOption();
  if (option.correct) {
    const points = state.attempt === 1 ? 2 : 1;
    state.score += points;
    state.missionScores[state.currentMission] += points;
    state.phase = "resolved";
    state.lastFeedback = {
      type: "correct",
      title: state.attempt === 1 ? "Criterio validado" : "Respuesta recuperada",
      message: `${question.explanation} Obtienes ${points} ${points === 1 ? "punto" : "puntos"}.`,
      action: "SIGUIENTE DESAFÍO",
    };
    recordAnswer(points, true, option);
    ambientAudio.effect("success");
    renderQuestion();
    speak(state.lastFeedback.message);
    return;
  }

  if (state.attempt === 1) {
    state.attemptedOptionIds.push(option.id);
    state.selectedOptionId = null;
    state.phase = "socratic";
    state.lastFeedback = {
      type: "wrong",
      title: "Hipótesis registrada",
      message: `El criterio seleccionado se relaciona con esta idea: «${option.misconception}». Hay una penalización de 1 punto disponible para este desafío.`,
      action: "DISCUTIR Y VOLVER A RESPONDER",
      socratic: true,
    };
    saveState();
    ambientAudio.effect("wrong");
    renderQuestion();
    speak(`${state.lastFeedback.message} Pregunta socrática. ${question.socratic}`);
    return;
  }

  state.phase = "resolved";
  state.lastFeedback = {
    type: "wrong",
    title: "Desafío sin puntaje",
    message: `${question.explanation} El segundo intento no fue correcto; obtienes 0 puntos y continuarás al siguiente desafío.`,
    action: "SIGUIENTE DESAFÍO",
  };
  recordAnswer(0, false, option);
  ambientAudio.effect("wrong");
  renderQuestion();
  speak(state.lastFeedback.message);
}

function recordAnswer(points, correct, option) {
  state.answers.push({
    questionId: currentQuestion().id,
    questionTitle: currentQuestion().title,
    missionIndex: state.currentMission,
    playerIndex: currentPlayerIndex(),
    attempts: state.attempt,
    points,
    correct,
    misconception: correct ? "" : option.misconception || "Criterio no identificado",
    at: new Date().toISOString(),
  });
  saveState();
  updateHud();
}

function renderFeedbackFromState() {
  const panel = $("#feedback-panel");
  if (!state.lastFeedback) {
    panel.className = "feedback-panel is-hidden";
    return;
  }
  const feedback = state.lastFeedback;
  panel.className = `feedback-panel is-${feedback.type}`;
  $("#feedback-icon").textContent = feedback.type === "correct" ? "✓" : "!";
  $("#feedback-kicker").textContent = feedback.type === "correct" ? "EVIDENCIA COHERENTE" : "REVISIÓN NECESARIA";
  $("#feedback-title").textContent = feedback.title;
  $("#feedback-message").textContent = feedback.message;
  $("#feedback-action").textContent = feedback.action;
  $("#socratic-box").classList.toggle("is-hidden", !feedback.socratic);
  if (feedback.socratic) {
    $("#socratic-category").textContent = `PREGUNTA SOCRÁTICA · ${currentQuestion().socraticCategory}`;
    $("#socratic-question").textContent = currentQuestion().socratic;
  }
}

function handleFeedbackAction() {
  if (state.phase === "socratic") {
    state.attempt = 2;
    state.phase = "answering";
    state.lastFeedback = null;
    state.selectedOptionId = null;
    renderQuestion();
    saveState();
    speak(`Segundo intento. ${currentQuestion().prompt}`);
    return;
  }
  if (state.phase === "resolved") advanceAfterQuestion();
}

function advanceAfterQuestion() {
  if (state.questionIndex < 4) {
    state.questionIndex += 1;
    resetQuestionState();
    setScreen("question");
    return;
  }
  if (!state.completedMissions.includes(state.currentMission)) state.completedMissions.push(state.currentMission);
  if (state.missionScores[state.currentMission] >= 6 && !state.badges.includes(state.currentMission)) state.badges.push(state.currentMission);
  resetQuestionState();
  setScreen("missionComplete");
}

function missionAnswerStats(missionIndex) {
  const answers = state.answers.filter((answer) => answer.missionIndex === missionIndex);
  return {
    first: answers.filter((answer) => answer.correct && answer.attempts === 1).length,
    second: answers.filter((answer) => answer.correct && answer.attempts === 2).length,
    zero: answers.filter((answer) => !answer.correct).length,
  };
}

function renderMissionComplete() {
  const mission = MISSIONS[state.currentMission];
  const score = state.missionScores[state.currentMission];
  const earned = score >= 6;
  const stats = missionAnswerStats(state.currentMission);
  $("#screen-mission-complete").style.setProperty("--mission-color", mission.color);
  $("#completion-badge-icon").innerHTML = earned
    ? badgeMarkup(state.currentMission, "completion-badge-image")
    : '<span class="badge-not-earned" aria-label="Insignia no obtenida">○</span>';
  $("#completion-title").textContent = earned ? `${mission.badge} obtenido` : `${mission.title} completada`;
  $("#completion-message").textContent = earned
    ? `Superaste el umbral de 6 puntos y recuperaste la insignia ${mission.badge}.`
    : `El sector quedó estabilizado, pero necesitas 6 puntos para obtener la insignia ${mission.badge}.`;
  $("#completion-score").textContent = `${score}/10`;
  $("#completion-first").textContent = stats.first;
  $("#completion-second").textContent = stats.second;
  $("#completion-zero").textContent = stats.zero;
  $("#completion-learning").textContent = mission.learning;
  $("#leave-completion").innerHTML = state.currentMission === 3 ? "VER REPORTE FINAL <span>→</span>" : "VOLVER AL MAPA <span>→</span>";
}

function leaveMissionCompletion() {
  if (state.currentMission === 3) {
    state.endedAt = Date.now();
    setScreen("final");
    return;
  }
  state.currentMission += 1;
  state.questionIndex = 0;
  resetQuestionState();
  setScreen("map");
}

function renderFinal() {
  const end = state.endedAt || Date.now();
  $("#final-score").textContent = state.score;
  $("#final-team").textContent = state.teamName;
  $("#final-duration").textContent = formatDuration(end - state.startedAt);
  $("#final-badges").textContent = `${state.badges.length} de 4`;
  $("#final-mission-grid").innerHTML = MISSIONS.map((mission, index) => {
    const earned = state.badges.includes(index);
    return `<article class="final-mission-card" style="--mission-color:${mission.color}"><span class="final-badge-visual">${earned ? badgeMarkup(index, "final-badge-image") : "○"}</span><h3>${mission.title}</h3><strong>${state.missionScores[index]}/10 PX</strong><small>${earned ? mission.badge : "Insignia no obtenida"}</small></article>`;
  }).join("");
  void warmPdfAssets();
}

function participantStats(playerIndex, snapshot = state) {
  const answers = snapshot.answers.filter((answer) => answer.playerIndex === playerIndex);
  return {
    decisions: answers.length,
    first: answers.filter((answer) => answer.correct && answer.attempts === 1).length,
    second: answers.filter((answer) => answer.correct && answer.attempts === 2).length,
    unresolved: answers.filter((answer) => !answer.correct).length,
  };
}

const PDF_IMAGE_CACHE = new Map();

function pdfEngine() {
  const namespace = globalThis.jspdf || globalThis.window?.jspdf;
  if (!namespace?.jsPDF) throw new Error("El generador PDF local no está disponible.");
  return namespace.jsPDF;
}

function pdfPalette(highContrast = settings.contrastLevel >= 50) {
  return highContrast
    ? {
        background: [255, 255, 255], surface: [255, 255, 255], dark: [0, 0, 0], teal: [0, 61, 153],
        tealSoft: [224, 238, 255], gold: [153, 94, 0], muted: [42, 42, 42], line: [0, 0, 0],
      }
    : {
        background: [245, 250, 249], surface: [255, 255, 255], dark: [12, 39, 50], teal: [8, 126, 120],
        tealSoft: [226, 244, 242], gold: [164, 106, 22], muted: [75, 101, 112], line: [174, 198, 202],
      };
}

function setPdfColor(documentPdf, method, color) {
  documentPdf[method](color[0], color[1], color[2]);
}

function pdfText(documentPdf, text, x, y, width, options = {}) {
  const { align = "left", color = [12, 39, 50], fontSize = 10, fontStyle = "normal", lineHeight = fontSize * 0.42 } = options;
  documentPdf.setFont("helvetica", fontStyle);
  documentPdf.setFontSize(fontSize);
  setPdfColor(documentPdf, "setTextColor", color);
  const lines = documentPdf.splitTextToSize(String(text), width);
  documentPdf.text(lines, x, y, { align });
  return y + Math.max(1, lines.length) * lineHeight;
}

function imageToPngDataUrl(path) {
  const absolutePath = assetAbsoluteUrl(path);
  if (PDF_IMAGE_CACHE.has(absolutePath)) return PDF_IMAGE_CACHE.get(absolutePath);
  const pending = new Promise((resolve, reject) => {
    const image = new Image();
    image.decoding = "async";
    image.onload = () => {
      try {
        const maximum = 640;
        const scale = Math.min(1, maximum / Math.max(image.naturalWidth, image.naturalHeight));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        const context = canvas.getContext("2d", { alpha: true });
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/png"));
      } catch (error) {
        reject(error);
      }
    };
    image.onerror = () => reject(new Error(`No se pudo cargar ${path}`));
    image.src = absolutePath;
  });
  PDF_IMAGE_CACHE.set(absolutePath, pending);
  return pending;
}

async function loadPdfImages(paths, imageResolver = imageToPngDataUrl) {
  const uniquePaths = [...new Set(paths.filter(Boolean))];
  const entries = await Promise.all(uniquePaths.map(async (path) => {
    try {
      return [path, await imageResolver(path)];
    } catch (error) {
      console.warn(error);
      return [path, null];
    }
  }));
  return new Map(entries);
}

function addPdfImage(documentPdf, images, path, x, y, width, height) {
  const data = images.get(path);
  if (!data) return false;
  documentPdf.addImage(data, "PNG", x, y, width, height, undefined, "FAST");
  return true;
}

function safePdfName(value) {
  const normalized = String(value || "participante").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9_-]+/g, "-").replace(/^-+|-+$/g, "");
  return normalized || "participante";
}

function addPdfFooter(documentPdf, palette, page, totalPages, highContrast) {
  const height = documentPdf.internal.pageSize.getHeight();
  setPdfColor(documentPdf, "setDrawColor", palette.line);
  documentPdf.setLineWidth(0.35);
  documentPdf.line(12, height - 17, documentPdf.internal.pageSize.getWidth() - 12, height - 17);
  pdfText(documentPdf, "Marcos Guerrero - Leonor Sánchez - Bryan Valarezo | Universidad Estatal de Milagro | CC BY-NC-SA 4.0", documentPdf.internal.pageSize.getWidth() / 2, height - 11.5, documentPdf.internal.pageSize.getWidth() - 28, {
    align: "center", color: palette.muted, fontSize: 7.5, lineHeight: 3,
  });
  const mode = highContrast ? "Alto contraste" : "Contraste estándar";
  pdfText(documentPdf, `${mode} | Página ${page} de ${totalPages}`, documentPdf.internal.pageSize.getWidth() - 14, height - 20.5, 70, {
    align: "right", color: palette.muted, fontSize: 7,
  });
}

function addInstructionCard(documentPdf, palette, number, title, body, y) {
  const width = documentPdf.internal.pageSize.getWidth();
  const bodyLines = documentPdf.splitTextToSize(body, 151);
  const height = Math.max(31, 17 + bodyLines.length * 4.2);
  setPdfColor(documentPdf, "setFillColor", palette.surface);
  setPdfColor(documentPdf, "setDrawColor", palette.line);
  documentPdf.roundedRect(14, y, width - 28, height, 2.5, 2.5, "FD");
  setPdfColor(documentPdf, "setFillColor", palette.teal);
  documentPdf.roundedRect(20, y + 6, 18, 18, 2, 2, "F");
  pdfText(documentPdf, String(number).padStart(2, "0"), 29, y + 17.2, 14, {
    align: "center", color: [255, 255, 255], fontSize: 10, fontStyle: "bold",
  });
  pdfText(documentPdf, title, 44, y + 11, 145, { color: palette.dark, fontSize: 11, fontStyle: "bold" });
  pdfText(documentPdf, body, 44, y + 19, 151, { color: palette.muted, fontSize: 8.7, lineHeight: 4.2 });
  return y + height + 6;
}

function addInstructionsHeader(documentPdf, palette, pageTitle, pageLabel, highContrast) {
  const width = documentPdf.internal.pageSize.getWidth();
  const height = documentPdf.internal.pageSize.getHeight();
  documentPdf.saveGraphicsState();
  setPdfColor(documentPdf, "setFillColor", palette.background);
  documentPdf.rect(0, 0, width, height, "F");
  documentPdf.restoreGraphicsState();
  documentPdf.saveGraphicsState();
  setPdfColor(documentPdf, "setFillColor", palette.dark);
  documentPdf.roundedRect(8, 8, width - 16, 26, 2, 2, "F");
  documentPdf.restoreGraphicsState();
  pdfText(documentPdf, "METRIX", 15, 21, 55, { color: [255, 255, 255], fontSize: 18, fontStyle: "bold" });
  pdfText(documentPdf, pageLabel, width - 15, 20.5, 105, {
    align: "right", color: highContrast ? [255, 220, 0] : [83, 229, 210], fontSize: 8, fontStyle: "bold",
  });
  pdfText(documentPdf, pageTitle, 14, 47, width - 28, { color: palette.dark, fontSize: 18, fontStyle: "bold" });
}

async function createInstructionsPdf(highContrast = settings.contrastLevel >= 50) {
  const JsPdf = pdfEngine();
  const documentPdf = new JsPdf({ orientation: "portrait", unit: "mm", format: "a4", compress: true });
  const palette = pdfPalette(highContrast);
  const pages = [
    {
      label: "GUÍA PASO A PASO 1 DE 5",
      title: "Antes de comenzar",
      intro: "Esta guía explica cómo completar METRIX de principio a fin. La actividad funciona sin conexión a internet y se realiza de forma individual.",
      cards: [
        [1, "Propósito de la experiencia", "Resolver desafíos sobre mediciones y sistemas de unidades mediante decisiones justificadas. El tutor socrático ayuda a revisar el razonamiento cuando la primera respuesta no es correcta."],
        [2, "Tiempo y estructura", "Reserva entre 60 y 75 minutos. Completarás 4 misiones, cada una con 5 desafíos, para un total de 20 preguntas de opción múltiple."],
        [3, "Material necesario", "Utiliza una computadora o dispositivo con navegador actualizado. Activa el sonido si deseas música y lectura hablada. No necesitas conexión a internet."],
        [4, "Antes de iniciar", "Lee la narrativa, revisa las reglas y abre la pestaña Accesibilidad para ajustar música, narración, velocidad, contraste y tamaño del texto."],
      ],
    },
    {
      label: "GUÍA PASO A PASO 2 DE 5",
      title: "Registro e interfaz",
      intro: "La barra superior permanece disponible durante toda la experiencia y muestra el tiempo, el puntaje, el progreso y las herramientas.",
      cards: [
        [5, "Registrar al participante", "Presiona Iniciar experiencia. Escribe tu nombre y selecciona un avatar. La actividad es individual y el avatar identifica tu recorrido."],
        [6, "Confirmar el registro", "Comprueba que el nombre y el avatar sean correctos. Después, confirma para acceder a las instrucciones iniciales y al mapa de misiones."],
        [7, "Interpretar el indicador de tiempo", "El cronómetro registra la duración de la sesión. El tiempo final aparecerá en el cierre, el diploma y el reporte de resultados."],
        [8, "Interpretar puntaje y progreso", "El puntaje máximo es 40 PX. El indicador de progreso muestra cuántos desafíos has completado de los 20 disponibles."],
        [9, "Usar Accesibilidad", "Puedes activar o desactivar música y narración, regular sus volúmenes, cambiar la velocidad de lectura y activar contraste alto o texto ampliado."],
      ],
    },
    {
      label: "GUÍA PASO A PASO 3 DE 5",
      title: "Cómo resolver cada desafío",
      intro: "Lee cada enunciado completo, analiza la evidencia y decide con base en la cantidad física, la unidad y el procedimiento mostrado.",
      cards: [
        [10, "Entrar en una misión", "Desde el mapa, revisa el objetivo y la narrativa de la misión. Presiona el botón de inicio cuando estés preparado para responder sus cinco desafíos."],
        [11, "Analizar la pregunta", "Identifica qué se solicita, revisa la información visual o numérica y relaciona las unidades antes de seleccionar una alternativa."],
        [12, "Enviar la respuesta", "Selecciona una sola opción y presiona el botón para responder. Las alternativas cambian de posición entre sesiones, por lo que debes leerlas siempre."],
        [13, "Usar la pregunta socrática", "Si la primera respuesta es incorrecta, lee la pregunta socrática. Examina el criterio que utilizaste y vuelve a decidir sin apresurarte."],
        [14, "Revisar la explicación", "Después de resolver el desafío, lee la retroalimentación. Compara la respuesta correcta con tu razonamiento antes de continuar."],
      ],
    },
    {
      label: "GUÍA PASO A PASO 4 DE 5",
      title: "Puntaje misiones e insignias",
      intro: "El puntaje valora tanto el acierto inicial como la capacidad de revisar una decisión después de la orientación socrática.",
      cards: [
        [15, "Primer intento", "Una respuesta correcta en el primer intento otorga 2 PX. Una respuesta incorrecta activa la orientación socrática y una segunda oportunidad."],
        [16, "Segundo intento", "Una respuesta correcta en el segundo intento otorga 1 PX. Si la segunda respuesta también es incorrecta, el desafío otorga 0 PX y continúa."],
        [17, "Puntaje por misión", "Cada misión vale hasta 10 PX. Al finalizar sus cinco desafíos verás los aciertos iniciales, las recuperaciones y las respuestas sin resolver."],
        [18, "Obtención de insignias", "Obtienes la insignia de una misión cuando alcanzas al menos 6 de sus 10 PX. La insignia aparece en el cierre y en los documentos finales."],
        [19, "Orden de las misiones", "Completa Cámara de Patrones, Corredor de Escalas, Sala de Precisión y Núcleo Dimensional. El mapa indica la misión activa y el avance acumulado."],
      ],
    },
    {
      label: "GUÍA PASO A PASO 5 DE 5",
      title: "Cierre documentos y solución de dificultades",
      intro: "La última pantalla resume tu desempeño y permite conservar evidencias de la sesión en archivos PDF.",
      cards: [
        [20, "Descargar el diploma", "Presiona Diploma guardar en PDF. El archivo incluye nombre, avatar, puntaje, duración e insignias obtenidas y se guarda directamente en el dispositivo."],
        [21, "Descargar el reporte", "Presiona Reporte guardar en PDF. El documento incluye el puntaje total, resultados por misión y el registro de los 20 desafíos."],
        [22, "Reiniciar la experiencia", "Descarga primero los documentos que necesites. Después, usa Reiniciar experiencia únicamente si deseas borrar el progreso y comenzar una sesión nueva."],
        [23, "Si no se escucha el audio", "Verifica los botones de música y narración, sus niveles de volumen y el volumen general del dispositivo. Presiona una vez la pantalla si el navegador solicita activar el audio."],
        [24, "Privacidad y funcionamiento local", "El progreso y las preferencias se guardan en el dispositivo. METRIX no requiere internet para funcionar ni envía las respuestas a un servidor externo."],
      ],
    },
  ];

  pages.forEach((page, pageIndex) => {
    if (pageIndex) documentPdf.addPage("a4", "portrait");
    addInstructionsHeader(documentPdf, palette, page.title, page.label, highContrast);
    let y = pdfText(documentPdf, page.intro, 14, 58, 182, { color: palette.muted, fontSize: 9.5, lineHeight: 4.5 }) + 5;
    page.cards.forEach(([number, title, body]) => { y = addInstructionCard(documentPdf, palette, number, title, body, y); });
  });

  const totalPages = documentPdf.getNumberOfPages();
  for (let page = 1; page <= totalPages; page += 1) {
    documentPdf.setPage(page);
    addPdfFooter(documentPdf, palette, page, totalPages, highContrast);
  }
  return documentPdf;
}

async function createDiplomaPdf(snapshot = state, imageResolver = imageToPngDataUrl, highContrast = settings.contrastLevel >= 50) {
  const JsPdf = pdfEngine();
  const documentPdf = new JsPdf({ orientation: "portrait", unit: "mm", format: "a4", compress: true });
  const palette = pdfPalette(highContrast);
  const participants = snapshot.players?.length ? snapshot.players : [snapshot.teamName || "Participante"];
  const earnedBadges = snapshot.badges || [];
  const imagePaths = [
    "assets/images/licencia-cc-by-nc-sa-4-0.png",
    ...participants.map((_, index) => AVATARS[snapshot.avatars?.[index] ?? 0]?.image),
    ...earnedBadges.map((index) => MISSIONS[index]?.badgeImage),
  ];
  const images = await loadPdfImages(imagePaths, imageResolver);
  const duration = formatDuration((snapshot.endedAt || Date.now()) - (snapshot.startedAt || Date.now()));

  participants.forEach((player, index) => {
    if (index) documentPdf.addPage("a4", "portrait");
    const width = documentPdf.internal.pageSize.getWidth();
    const height = documentPdf.internal.pageSize.getHeight();
    setPdfColor(documentPdf, "setFillColor", palette.background);
    documentPdf.rect(0, 0, width, height, "F");
    setPdfColor(documentPdf, "setDrawColor", palette.dark);
    documentPdf.setLineWidth(highContrast ? 1 : 0.7);
    documentPdf.roundedRect(7, 7, width - 14, height - 14, 3, 3, "S");
    setPdfColor(documentPdf, "setFillColor", palette.dark);
    documentPdf.roundedRect(9, 9, width - 18, 24, 2, 2, "F");
    pdfText(documentPdf, "METRIX", 16, 21, 55, { color: [255, 255, 255], fontSize: 19, fontStyle: "bold" });
    pdfText(documentPdf, "UNIVERSIDAD ESTATAL DE MILAGRO", width - 16, 20.5, 100, { align: "right", color: [255, 255, 255], fontSize: 9, fontStyle: "bold" });
    pdfText(documentPdf, "TUTOR SOCRÁTICO GAMIFICADO", width - 16, 26, 100, { align: "right", color: highContrast ? [255, 220, 0] : [83, 229, 210], fontSize: 7.5 });

    const avatarPath = AVATARS[snapshot.avatars?.[index] ?? 0]?.image || AVATARS[0].image;
    setPdfColor(documentPdf, "setFillColor", palette.tealSoft);
    setPdfColor(documentPdf, "setDrawColor", palette.teal);
    documentPdf.roundedRect(85, 39, 40, 40, 20, 20, "FD");
    addPdfImage(documentPdf, images, avatarPath, 90, 44, 30, 30);

    pdfText(documentPdf, "RECONOCIMIENTO DE PARTICIPACIÓN", width / 2, 91, width - 30, { align: "center", color: palette.dark, fontSize: 20, fontStyle: "bold" });
    pdfText(documentPdf, "Mediciones y sistemas de unidades", width / 2, 99, width - 30, { align: "center", color: palette.teal, fontSize: 11, fontStyle: "bold" });
    pdfText(documentPdf, "Se reconoce a", width / 2, 112, 150, { align: "center", color: palette.muted, fontSize: 10 });
    pdfText(documentPdf, player, width / 2, 124, 174, { align: "center", color: palette.teal, fontSize: 24, fontStyle: "bold", lineHeight: 9 });
    pdfText(documentPdf, "por completar individualmente las cuatro misiones del Protocolo de Medición y justificar sus decisiones mediante el diálogo socrático.", width / 2, 139, 158, {
      align: "center", color: palette.dark, fontSize: 10.5, lineHeight: 5,
    });

    const stats = participantStats(index, snapshot);
    const summaries = [
      ["PUNTAJE", `${Number(snapshot.score || 0)}/40 PX`], ["DURACIÓN", duration],
      ["DECISIONES", String(stats.decisions)], ["RECUPERADAS", String(stats.second)],
    ];
    summaries.forEach(([label, value], summaryIndex) => {
      const cardWidth = 42;
      const x = 14 + summaryIndex * 46;
      setPdfColor(documentPdf, "setFillColor", palette.surface);
      setPdfColor(documentPdf, "setDrawColor", palette.line);
      documentPdf.roundedRect(x, 157, cardWidth, 24, 2, 2, "FD");
      pdfText(documentPdf, label, x + cardWidth / 2, 165, cardWidth - 4, { align: "center", color: palette.muted, fontSize: 7, fontStyle: "bold" });
      pdfText(documentPdf, value, x + cardWidth / 2, 175, cardWidth - 4, { align: "center", color: summaryIndex === 0 ? palette.gold : palette.dark, fontSize: summaryIndex === 1 ? 10 : 13, fontStyle: "bold" });
    });

    pdfText(documentPdf, "INSIGNIAS OBTENIDAS", width / 2, 194, 160, { align: "center", color: palette.dark, fontSize: 9, fontStyle: "bold" });
    if (earnedBadges.length) {
      const badgeWidth = 38;
      const totalWidth = earnedBadges.length * badgeWidth;
      earnedBadges.forEach((missionIndex, badgeIndex) => {
        const mission = MISSIONS[missionIndex];
        const x = (width - totalWidth) / 2 + badgeIndex * badgeWidth;
        addPdfImage(documentPdf, images, mission.badgeImage, x + 8, 199, 22, 22);
        pdfText(documentPdf, mission.badge, x + badgeWidth / 2, 225, badgeWidth - 3, { align: "center", color: palette.muted, fontSize: 6.8, fontStyle: "bold", lineHeight: 3 });
      });
    } else {
      pdfText(documentPdf, "Sin insignias obtenidas en esta sesión.", width / 2, 210, 150, { align: "center", color: palette.muted, fontSize: 9 });
    }

    setPdfColor(documentPdf, "setDrawColor", palette.line);
    documentPdf.line(28, 244, 82, 244);
    documentPdf.line(128, 244, 182, 244);
    pdfText(documentPdf, "Firma docente", 55, 249, 54, { align: "center", color: palette.muted, fontSize: 7.5 });
    pdfText(documentPdf, "Institución educativa", 155, 249, 54, { align: "center", color: palette.muted, fontSize: 7.5 });
    addPdfImage(documentPdf, images, "assets/images/licencia-cc-by-nc-sa-4-0.png", 15, 257, 30, 11);
  });

  const totalPages = documentPdf.getNumberOfPages();
  for (let page = 1; page <= totalPages; page += 1) {
    documentPdf.setPage(page);
    addPdfFooter(documentPdf, palette, page, totalPages, highContrast);
  }
  return documentPdf;
}

function reportHeader(documentPdf, palette, snapshot, duration, highContrast) {
  const width = documentPdf.internal.pageSize.getWidth();
  documentPdf.saveGraphicsState();
  setPdfColor(documentPdf, "setFillColor", palette.background);
  documentPdf.rect(0, 0, width, documentPdf.internal.pageSize.getHeight(), "F");
  documentPdf.restoreGraphicsState();
  documentPdf.saveGraphicsState();
  setPdfColor(documentPdf, "setFillColor", palette.dark);
  documentPdf.roundedRect(8, 8, width - 16, 23, 2, 2, "F");
  documentPdf.restoreGraphicsState();
  pdfText(documentPdf, "METRIX - REPORTE FINAL", 15, 19.5, 110, { color: [255, 255, 255], fontSize: 16, fontStyle: "bold" });
  pdfText(documentPdf, "MEDICIONES Y SISTEMAS DE UNIDADES", width - 15, 18, 130, { align: "right", color: highContrast ? [255, 220, 0] : [83, 229, 210], fontSize: 8, fontStyle: "bold" });
  pdfText(documentPdf, `${new Date().toLocaleDateString("es-EC")} | Duración: ${duration}`, width - 15, 24.5, 130, { align: "right", color: [255, 255, 255], fontSize: 7.5 });
  pdfText(documentPdf, snapshot.teamName || snapshot.players?.[0] || "Participante", 14, 44, 178, { color: palette.dark, fontSize: 17, fontStyle: "bold" });
  pdfText(documentPdf, `${Number(snapshot.score || 0)}/40 PX`, width - 14, 45, 70, { align: "right", color: palette.gold, fontSize: 19, fontStyle: "bold" });
}

function reportTableHeader(documentPdf, palette, y, columns) {
  setPdfColor(documentPdf, "setFillColor", palette.tealSoft);
  setPdfColor(documentPdf, "setDrawColor", palette.line);
  let x = 8;
  columns.forEach((column) => {
    setPdfColor(documentPdf, "setFillColor", palette.tealSoft);
    documentPdf.rect(x, y, column.width, 8, "FD");
    pdfText(documentPdf, column.label, x + 2, y + 5.2, column.width - 4, { color: palette.dark, fontSize: 7, fontStyle: "bold" });
    x += column.width;
  });
  return y + 8;
}

async function createReportPdf(snapshot = state, imageResolver = imageToPngDataUrl, highContrast = settings.contrastLevel >= 50) {
  const JsPdf = pdfEngine();
  const documentPdf = new JsPdf({ orientation: "landscape", unit: "mm", format: "a4", compress: true });
  const palette = pdfPalette(highContrast);
  const earnedBadges = snapshot.badges || [];
  const avatarPath = AVATARS[snapshot.avatars?.[0] ?? 0]?.image || AVATARS[0].image;
  const imagePaths = [avatarPath, ...earnedBadges.map((index) => MISSIONS[index]?.badgeImage)];
  const images = await loadPdfImages(imagePaths, imageResolver);
  const duration = formatDuration((snapshot.endedAt || Date.now()) - (snapshot.startedAt || Date.now()));
  reportHeader(documentPdf, palette, snapshot, duration, highContrast);

  const cardY = 56;
  const cardWidth = 66.25;
  MISSIONS.forEach((mission, index) => {
    const x = 8 + index * (cardWidth + 5);
    setPdfColor(documentPdf, "setFillColor", palette.surface);
    setPdfColor(documentPdf, "setDrawColor", palette.line);
    documentPdf.roundedRect(x, cardY, cardWidth, 55, 2, 2, "FD");
    pdfText(documentPdf, `MISIÓN ${mission.id}`, x + 4, cardY + 8, cardWidth - 8, { color: palette.teal, fontSize: 7, fontStyle: "bold" });
    pdfText(documentPdf, mission.title, x + 4, cardY + 16, cardWidth - 8, { color: palette.dark, fontSize: 10, fontStyle: "bold", lineHeight: 4.2 });
    pdfText(documentPdf, `${snapshot.missionScores?.[index] || 0}/10 PX`, x + 4, cardY + 33, 30, { color: palette.gold, fontSize: 15, fontStyle: "bold" });
    if (earnedBadges.includes(index)) {
      addPdfImage(documentPdf, images, mission.badgeImage, x + cardWidth - 23, cardY + 25, 17, 17);
      pdfText(documentPdf, mission.badge, x + 4, cardY + 49, cardWidth - 8, { color: palette.muted, fontSize: 6.5, fontStyle: "bold" });
    } else {
      pdfText(documentPdf, "Insignia no obtenida", x + 4, cardY + 49, cardWidth - 8, { color: palette.muted, fontSize: 6.5 });
    }
  });

  const player = snapshot.players?.[0] || snapshot.teamName || "Participante";
  const stats = participantStats(0, snapshot);
  setPdfColor(documentPdf, "setFillColor", palette.surface);
  setPdfColor(documentPdf, "setDrawColor", palette.line);
  documentPdf.roundedRect(8, 120, 281, 54, 2, 2, "FD");
  addPdfImage(documentPdf, images, avatarPath, 15, 129, 34, 34);
  pdfText(documentPdf, "RESUMEN INDIVIDUAL", 57, 133, 90, { color: palette.teal, fontSize: 8, fontStyle: "bold" });
  pdfText(documentPdf, player, 57, 144, 100, { color: palette.dark, fontSize: 16, fontStyle: "bold" });
  [["Decisiones", stats.decisions], ["Correctas iniciales", stats.first], ["Recuperadas", stats.second], ["Sin resolver", stats.unresolved]].forEach(([label, value], index) => {
    const x = 164 + index * 30;
    pdfText(documentPdf, String(value), x, 143, 27, { align: "center", color: palette.gold, fontSize: 16, fontStyle: "bold" });
    pdfText(documentPdf, label, x, 153, 27, { align: "center", color: palette.muted, fontSize: 6.5, lineHeight: 3 });
  });
  pdfText(documentPdf, "Los resultados corresponden únicamente a esta sesión formativa individual y no sustituyen una evaluación validada.", 57, 166, 220, { color: palette.muted, fontSize: 7.5 });

  documentPdf.addPage("a4", "landscape");
  reportHeader(documentPdf, palette, { ...snapshot, teamName: "Registro formativo" }, duration, highContrast);
  const columns = [
    { label: "MISIÓN", width: 16 }, { label: "DESAFÍO", width: 55 }, { label: "PARTICIPANTE", width: 38 },
    { label: "INTENTOS", width: 18 }, { label: "PX", width: 12 }, { label: "EVIDENCIA", width: 142 },
  ];
  let y = reportTableHeader(documentPdf, palette, 54, columns);
  const answers = snapshot.answers || [];
  if (!answers.length) pdfText(documentPdf, "No hay respuestas registradas en esta sesión.", 10, y + 10, 270, { color: palette.muted, fontSize: 10 });
  answers.forEach((answer) => {
    const values = [
      String(MISSIONS[answer.missionIndex]?.id || answer.missionIndex + 1), answer.questionTitle || "Desafío",
      snapshot.players?.[answer.playerIndex] || player, String(answer.attempts), String(answer.points),
      answer.correct ? "Resuelta correctamente" : answer.misconception || "Sin resolver",
    ];
    const lineSets = values.map((value, index) => documentPdf.splitTextToSize(String(value), columns[index].width - 4));
    const rowHeight = Math.max(8, ...lineSets.map((lines) => lines.length * 3.2 + 3));
    if (y + rowHeight > 187) {
      documentPdf.addPage("a4", "landscape");
      reportHeader(documentPdf, palette, { ...snapshot, teamName: "Registro formativo" }, duration, highContrast);
      y = reportTableHeader(documentPdf, palette, 54, columns);
    }
    let x = 8;
    columns.forEach((column, index) => {
      setPdfColor(documentPdf, "setFillColor", palette.surface);
      setPdfColor(documentPdf, "setDrawColor", palette.line);
      documentPdf.rect(x, y, column.width, rowHeight, "FD");
      documentPdf.setFont("helvetica", "normal");
      documentPdf.setFontSize(6.6);
      setPdfColor(documentPdf, "setTextColor", palette.dark);
      documentPdf.text(lineSets[index], x + 2, y + 4.5);
      x += column.width;
    });
    y += rowHeight;
  });

  const totalPages = documentPdf.getNumberOfPages();
  for (let page = 1; page <= totalPages; page += 1) {
    documentPdf.setPage(page);
    addPdfFooter(documentPdf, palette, page, totalPages, highContrast);
  }
  return documentPdf;
}

async function warmPdfAssets() {
  const paths = ["assets/images/licencia-cc-by-nc-sa-4-0.png", AVATARS[state.avatars?.[0] ?? 0]?.image, ...state.badges.map((index) => MISSIONS[index]?.badgeImage)];
  await loadPdfImages(paths);
}

async function downloadPdf(button, loadingLabel, builder, filename, successMessage) {
  const originalLabel = button.textContent;
  button.disabled = true;
  button.setAttribute("aria-busy", "true");
  button.textContent = loadingLabel;
  try {
    const documentPdf = await builder();
    documentPdf.save(filename);
    showToast(successMessage);
  } catch (error) {
    console.error(error);
    showToast("No se pudo crear el PDF. Cierra y vuelve a abrir la aplicación para reintentar.");
  } finally {
    button.disabled = false;
    button.removeAttribute("aria-busy");
    button.textContent = originalLabel;
  }
}

function printDiplomas() {
  return downloadPdf($("#print-diplomas"), "GENERANDO DIPLOMA…", () => createDiplomaPdf(), `METRIX-Diploma-${safePdfName(state.players?.[0] || state.teamName)}.pdf`, "Diploma PDF generado y descargado.");
}

function printReport() {
  return downloadPdf($("#print-report"), "GENERANDO REPORTE…", () => createReportPdf(), `METRIX-Reporte-${safePdfName(state.players?.[0] || state.teamName)}.pdf`, "Reporte PDF generado y descargado.");
}

function downloadInstructions() {
  return downloadPdf($("#download-instructions"), "GENERANDO GUÍA…", () => createInstructionsPdf(), "METRIX-Instrucciones-paso-a-paso.pdf", "Guía de instrucciones PDF generada y descargada.");
}

function bindEvents() {
  document.addEventListener("pointerdown", () => ambientAudio.unlock(), { once: true });
  $("#start-button").addEventListener("click", () => {
    if (savedCandidate?.startedAt && !savedCandidate?.endedAt && !window.confirm("Hay una sesión guardada. ¿Deseas borrarla para iniciar una experiencia nueva?")) return;
    storageAction("removeItem", STORAGE_KEY);
    savedCandidate = null;
    $("#resume-button").classList.add("is-hidden");
    state = freshState();
    setScreen("setup");
  });
  $("#resume-button").addEventListener("click", () => {
    if (!savedCandidate) return;
    state = savedCandidate;
    setScreen(state.screen || "map");
    showToast("Sesión recuperada en este dispositivo.");
  });
  $("#brand-button").addEventListener("click", () => {
    if (!state.startedAt) setScreen("landing", { narrate: false });
    else showToast("La sesión está activa. Utiliza el mapa o completa el desafío actual.");
  });
  $$('[data-action="go-landing"]').forEach((button) => button.addEventListener("click", () => setScreen("landing", { narrate: false })));
  $$('[data-action="go-setup"]').forEach((button) => button.addEventListener("click", () => setScreen("setup")));
  $$('[data-action="go-map"]').forEach((button) => button.addEventListener("click", () => setScreen("map")));
  $("#team-name").addEventListener("input", (event) => {
    state.teamName = event.target.value;
    state.players[0] = event.target.value;
  });
  $("#confirm-team").addEventListener("click", () => {
    state.teamName = $("#team-name").value.trim();
    state.players = [state.teamName];
    const validation = teamValidationMessage();
    $("#setup-message").textContent = validation;
    if (validation) return;
    state.startedAt = Date.now();
    setScreen("briefing");
  });
  $("#enter-map").addEventListener("click", () => setScreen("map"));
  $("#start-mission").addEventListener("click", () => {
    resetQuestionState();
    setScreen("question");
  });
  $("#submit-answer").addEventListener("click", submitCurrentAnswer);
  $("#feedback-action").addEventListener("click", handleFeedbackAction);
  $("#leave-completion").addEventListener("click", leaveMissionCompletion);
  $("#print-diplomas").addEventListener("click", printDiplomas);
  $("#print-report").addEventListener("click", printReport);
  $("#download-instructions").addEventListener("click", downloadInstructions);
  $("#restart-experience").addEventListener("click", () => {
    if (!window.confirm("¿Deseas borrar el progreso y comenzar una experiencia nueva?")) return;
    storageAction("removeItem", STORAGE_KEY);
    window.speechSynthesis?.cancel();
    state = freshState();
    savedCandidate = null;
    $("#resume-button").classList.add("is-hidden");
    setScreen("landing");
  });

  $("#open-foundation").addEventListener("click", () => $("#foundation-dialog").showModal());

  $("#accessibility-toggle").addEventListener("click", () => {
    const panel = $("#settings-accessibility");
    const opening = panel.hidden;
    panel.hidden = !opening;
    $("#accessibility-toggle").setAttribute("aria-expanded", String(opening));
  });

  $("#music-toggle").addEventListener("click", () => {
    settings.music = !settings.music;
    ambientAudio.unlock();
    applySettings();
    saveSettings();
  });
  $("#narration-toggle").addEventListener("click", () => {
    settings.narration = !settings.narration;
    if (!settings.narration) {
      narrationGeneration += 1;
      window.speechSynthesis?.cancel();
    }
    applySettings();
    saveSettings();
    if (settings.narration) speak(narrationTextForScreen(state.screen));
  });
  $("#music-volume").addEventListener("input", (event) => {
    settings.musicVolume = Number(event.target.value);
    applySettings();
    saveSettings();
  });
  $("#narration-volume").addEventListener("input", (event) => {
    settings.narrationVolume = Number(event.target.value);
    applySettings();
    saveSettings();
  });
  $("#narration-volume").addEventListener("change", () => {
    if (settings.narration) speak(narrationTextForScreen(state.screen));
  });
  $("#narration-rate").addEventListener("input", (event) => {
    settings.narrationRate = Number(event.target.value);
    applySettings();
    saveSettings();
  });
  $("#narration-rate").addEventListener("change", () => {
    if (settings.narration) speak(narrationTextForScreen(state.screen));
  });
  $("#contrast-toggle").addEventListener("click", () => {
    settings.contrastLevel = settings.contrastLevel >= 50 ? 0 : 100;
    applySettings();
    saveSettings();
  });
  $("#text-toggle").addEventListener("click", () => {
    settings.textScale = settings.textScale > 100 ? 100 : 120;
    applySettings();
    saveSettings();
  });
}

function initialize() {
  loadLocalData();
  bindEvents();
  applySettings();
  renderSetup();
  renderBriefing();
  if (savedCandidate && savedCandidate.startedAt) {
    $("#resume-button").classList.remove("is-hidden");
    $("#resume-button").textContent = savedCandidate.endedAt ? "VER RESULTADO GUARDADO" : "REANUDAR SESIÓN";
  }
  updateHud();
  updateTimer();
  timerHandle = window.setInterval(updateTimer, 1000);
}

if (typeof document === "undefined") {
  globalThis.METRIX_TEST_API = { MISSIONS, QUESTIONS, LETTERS, AVATARS, buildCorrectLetterSchedule, createDiplomaPdf, createReportPdf, createInstructionsPdf, naturalizeSpeechText };
} else {
  initialize();
}
